
AGENT_NAME=$1
IMAGE_TAG=$2
KUBERNETES_NAMESPACE=$3
STORAGE_CLASS_NAME=$4
AGENT_KEY=$AGENT_NAME

tee templates/agent-${AGENT_NAME}.yaml > /dev/null <<TWIDDLEBUGYAML

apiVersion: v1
kind: List
metadata:
  name: agent-${AGENT_NAME}-resources
items:

- apiVersion: v1
  kind: PersistentVolumeClaim
  metadata:
    name: agent-${AGENT_NAME}-plugin-claim
  spec:
    accessModes:
      - ReadWriteOnce
    storageClassName: ${STORAGE_CLASS_NAME}
    resources:
      requests:
        storage: 5Gi

- apiVersion: v1
  kind: PersistentVolumeClaim
  metadata:
    name: agent-${AGENT_NAME}-docker-claim
  spec:
    accessModes:
      - ReadWriteOnce
    storageClassName: ${STORAGE_CLASS_NAME}
    resources:
      requests:
        storage: 12Gi

- apiVersion: apps/v1
  kind: Deployment
  metadata:
    name: agent-${AGENT_NAME}
    labels:
      app: agent-${AGENT_NAME}
      platform: kaholo
      type: agent
  spec:
    strategy:
      type: Recreate
    replicas: 1
    selector:
      matchLabels:
        app: agent-${AGENT_NAME}
    template:
      metadata:
        labels:
          app: agent-${AGENT_NAME}
          platform: kaholo
          type: agent
      spec:
        # tolerations: # prevent other services to run on the same node
        # - effect: NoSchedule
        #   key: purpose
        #   operator: Equal
        #   value: agents
        # nodeSelector: # make schedule only on specific nodes
        #   purpose: agents
        imagePullSecrets:
        - name: regcred
        containers:
        - name: agent
          imagePullPolicy: IfNotPresent
          image: ${IMAGE_TAG}
          securityContext:
            privileged: true
          args:
            ['bash', '-c', 'source /vault/secrets/config && ./startup.sh']
          ports:
          - containerPort: 8092
          env:
          - name: PORT
            value: "8092"
          - name: AGENT_NAME
            value: ${AGENT_NAME}
          - name: AGENT_KEY
            value: ${AGENT_KEY}
          - name: PRIVATE_IP
            value: agent-${AGENT_NAME}
          - name: SERVER_URL
            value: http://platform:8090
          - name: AMQP_RESULT_QUEUE
            value: "Action/Execution/TwiddlebugResult"
          - name: DOCKER_HOST
            value: "unix:///var/run/docker.sock"
          - name: PLUGINS_DIR_PATH
            value: "/usr/src/app/libs/plugins"
          - name: RPC_REQUEST_TIMEOUT
            value: "60000"
          - name: RABBITMQ_USERNAME
            valueFrom:
              secretKeyRef:
                name: "rabbitmq-agent-creds"
                key: username
                optional: true
          - name: RABBITMQ_PASSWORD
            valueFrom:
              secretKeyRef:
                name: "rabbitmq-agent-creds"
                key: password
                optional: true
          resources:
            requests: # TODO - different than in Helm Chart
              memory: "128Mi"
              cpu: "100m"
            limits:
              memory: "4096Mi"
              cpu: "1000m"
          volumeMounts:
          - mountPath: "/usr/src/app/libs/plugins"
            name: plugin-agent-${AGENT_NAME}-persistent-storage
          - mountPath: /var/lib/docker
            name: docker-agent-${AGENT_NAME}-persistent-storage        
          - name: env-secret
            mountPath: /vault/secrets
            readOnly: true
        volumes:
        - name: plugin-agent-${AGENT_NAME}-persistent-storage
          persistentVolumeClaim:
            claimName: agent-${AGENT_NAME}-plugin-claim
        - name: docker-agent-${AGENT_NAME}-persistent-storage
          persistentVolumeClaim:
            claimName: agent-${AGENT_NAME}-docker-claim
        - name: env-secret
          secret:
            secretName: agent-env-secret

TWIDDLEBUGYAML
