#!/usr/bin/env bash

usage() {
    echo "ERROR: Please use under 'kaholo-iac-jfrog/bin' directory with exactly ./agent.sh [launch,start,stop,status,enter,restart|update|delete] namespace in which Kaholo is deployed, agent name and agent container image tag"
    exit 22
}

command="$1"
if [[ -z "$command" ]]; then
    usage
fi

kuberenetes_namespace="$2"
agent_name="$3"
docker_image="$4"
storage_class_name="$5"

if [[ -z "$agent_name" ]]; then
    echo "ERROR: Please provide an agent name"
    usage
fi


launch_agent() {
    if kubectl get deployment agent-${agent_name} -n ${kuberenetes_namespace} > /dev/null 2>&1
    then
        echo "Agent with name ${agent_name} already created!"
        exit 1
    fi
    ./agent-yaml-template.sh "$agent_name" "$docker_image" "$kuberenetes_namespace" "${storage_class_name}"
    kubectl create -f templates/agent-${agent_name}.yaml -n ${kuberenetes_namespace}
}

start_agent() {
    kubectl scale deployment agent-${agent_name} --replicas 1 -n ${kuberenetes_namespace}
}

status_agent() {
    kubectl get pod -l=app=agent-${agent_name} -n ${kuberenetes_namespace}
}

enter_agent() {
    pod_name=$(kubectl get pod --no-headers=true -l=app=agent-${agent_name} -n ${kuberenetes_namespace})
    kubectl exec --stdin --tty ${pod_name} -n ${kuberenetes_namespace} -c agent -- /bin/bash
}

restart_agent() {
    kubectl rollout restart deployment agent-${agent_name} -n ${kuberenetes_namespace}
}

stop_agent() {
    kubectl scale deployment agent-${agent_name} --replicas 0 -n ${kuberenetes_namespace}
}

update_agent() {
    if ! kubectl get deployment agent-${agent_name} -n ${kuberenetes_namespace} > /dev/null 2>&1
    then
        echo "Agent with name ${agent_name} has not been created yet!"
        exit 1
    fi
    cp templates/agent-${agent_name}.yaml templates/backup/agent-${agent_name}.yaml.$(date +'%Y%m%dT%H%M')
    ./agent-yaml-template.sh "$agent_name" "$docker_image" "$kuberenetes_namespace" "${storage_class_name}"
    kubectl apply -f templates/agent-${agent_name}.yaml -n ${kuberenetes_namespace}
}

delete_agent() {
    if ! kubectl get deployment agent-${agent_name} -n ${kuberenetes_namespace} > /dev/null 2>&1
    then
        echo "Agent with name ${agent_name} has not been created yet!"
        exit 1
    fi
    cp templates/agent-${agent_name}.yaml templates/backup/agent-${agent_name}.yaml.$(date +'%Y%m%dT%H%M')
    kubectl delete -f templates/agent-${agent_name}.yaml -n ${kuberenetes_namespace}
    kubectl delete deployment agent-${agent_name} -n ${kuberenetes_namespace}
    kubectl delete pvc agent-${agent_name}-plugin-claim agent-${agent_name}-docker-claim -n ${kuberenetes_namespace}
    # rm templates/agent-${agent_name}.yaml
}

case "$command" in
launch|start|stop|status|enter|restart|update|delete)
    ${command}_agent "$@"
    ;;
*)
    usage
    ;;
esac
