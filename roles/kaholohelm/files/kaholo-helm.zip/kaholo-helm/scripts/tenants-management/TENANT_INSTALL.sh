#!/bin/bash -
set -e  # Exit immediately if a command exits with a non-zero status
set -o pipefail # Causes a pipeline to return the exit status of the last command in the pipe that returned a non-zero return value
HOME_DIR=$(pwd)

# Example executions:
# ./TENANT_INSTALL.sh \
#   -t 'v5.1.1' \
#   -n 'departament1' \
#   -d 'mycompany.net' \
#   -s 'departament1' \
#   -o 'standard' \
#   -f -b


PROGNAME=$0

usage() {
  cat << EOF >&2
Usage: $PROGNAME

 -n    <NAMESPACE_NAME>:  Name of Kaholo Helm Release and Kubernetes Namespace (required)
 -d    <DOMAIN>:          Domain name used in Ingress resources (required)
 -s    <SUBDOMAIN>:       Subdomain name used in Ingress resources (required)
 -o    <RWO_SC>:          ReadWriteOnce StorageClass name (required)
 -x    <RWM_SC>:          ReadWriteMany StorageClass name (required if DEPLOY_NFS not used, if DEPLOY_NFS is true will be replaced by '${NAMESPACE_NAME}-nfs')
 -t    <KAH_TAG>:         Image Tag of Kaholo containers (required)
 -k    <SERVER_KEY>:      Server Key used by Kaholo (secret, can be ommited - then will be generated randomly)
 -l    <BACKUPS_BUCKET>:  GCP Cloud Storage bucket name used for backups (required if BACKUPS_EXT flag '-e' is used)
 -r    <EXT_RABBITMQ>:    External RabbitMQ comma separeted data: hostname, username, password that will be used vhosts and user creation, plus additionally hostname, port and schema used for internal and external connections, eg. 'rabbitmq.mydomain.com,admin,password123,rabbitmq.internaldns,5672,rabbitmq.external.com,5671,amqps'
 -q    <EXT_REDIS>:       External Redis comma separeted data: schema prefix: 'redis://' or 'rediss://', hostname, port, username, password eg. 'redis://,redis-master.redis,6379,admin,password123'
 -u    <AGENT_RES>:       Custom Kaholo Agent resources requests and limits (format: '{"limits":{"cpu":"4","memory":"8Gi"},"requests":{"cpu:"2","memory:"6Gi"}}') (ignored if REQ_RESOURCES flag '-v' is used)
 -h    <INGRESS_SECRET>:  Secret Name for Ingress (can be ommited)
 -m    <MONGO_EXPOSED>:   Decide if MongoDB will be exposed using LoadBalancer services
 -b    <BACKUPS>:         Decide if backup creation jobs should be created
 -e    <BACKUPS_EXT>:     Decide if backups should be uploaded to GCP GCS external storage
 -p    <METRICS>:         Decide if Prometheus metrics exporters should be enabled
 -a    <AGENT_NODES>      Decide if dedicated K8S nodes with taint/label 'agents' should be used for Kaholo Agents deployments
 -c    <CL_DOCKER_NODES>: Decide if dedicated K8S nodes with taint/label 'cl-docker-daemon' should be used for Docker Daemon deployments
 -g    <COPY_SECRETS>:    Decide if regcred, wildcard-certificate, backups-uploader-private-key and dockerhub-auth Secrets should be copied from 'shd' namespacae
 -f    <DEPLOY_NFS>:      Decide if Custom NFS server should be deployed and used for ReadWriteMany volumes
 -i    <ALLOW_EGR_INK8S>: Decide if Kaholo Agent and Code Evaluation containers should be allowed to make connections to Pods in K8S (managed by NetworkPolicy, only K8S DNS allowed)
 -v    <REQ_RESOURCES>:   Decide if Kaholo services and dependencies should use suggested resource requests and limits
 -j    <DYNAMIC_AGENTS>:  Decide if Dynamic Agents should be used with GCP_VM driver

EOF
  exit 1
}

# verbose_level=0
AGENT_KEY=$(tr -dc A-Za-z0-9 </dev/urandom | head -c 32 ; echo '')
SERVER_KEY=$(tr -dc A-Za-z0-9 </dev/urandom | head -c 32 ; echo '')
MONGO_EXPOSED="false"
BACKUPS="false"
BACKUPS_EXT="false"
METRICS="false"
AGENT_NODES="false"
CL_DOCKER_NODES="false"
COPY_SECRETS="false"
DEPLOY_NFS="false"
ALLOW_EGR_INK8S="false"
REQ_RESOURCES="false"
DYNAMIC_AGENTS="false"
INGRESS_SECRET=""
while getopts t:n:d:s:o:x:k:l:r:q:u:h:mbepacgfivj opt; do
  case $opt in
    (n) NAMESPACE_NAME=$OPTARG;;
    (d) DOMAIN=$OPTARG;;
    (s) SUBDOMAIN=$OPTARG;;
    (o) RWO_SC=$OPTARG;;
    (x) RWM_SC=$OPTARG;;
    (t) KAH_TAG=$OPTARG;;
    (k) SERVER_KEY=$OPTARG;;
    (l) BACKUPS_BUCKET=$OPTARG;;
    (r) EXT_RABBITMQ=$OPTARG;;
    (q) EXT_REDIS=$OPTARG;;
    (u) AGENT_RES=$OPTARG;;
    (h) INGRESS_SECRET=$OPTARG;;
    (m) MONGO_EXPOSED=true;;
    (b) BACKUPS=true;;
    (e) BACKUPS_EXT=true;;
    (p) METRICS=true;;
    (a) AGENT_NODES=true;;
    (c) CL_DOCKER_NODES=true;;
    (g) COPY_SECRETS=true;;
    (f) DEPLOY_NFS=true;;
    (i) ALLOW_EGRESS_IN_K8S=true;;
    (v) REQ_RESOURCES=true;;
    (j) DYNAMIC_AGENTS=true;;

    (*) usage
  esac
done
shift "$((OPTIND - 1))"

echo Remaining arguments: "$@"


BASE_PATH=$(pwd)/../../

LICENSE_PUBLIC_KEY=$(cat ${BASE_PATH}/kaholo-license.pub)
GITHUB_OAUTH_CLIENT_ID="TODO"
GITHUB_OAUTH_CLIENT_SECRET="TODO"
REGISTRY="matankaholo/"

FORCE_GLOBAL_IMAGE_TAG="false"
if ! [ -z "${KAH_TAG}" ]
then
  FORCE_GLOBAL_IMAGE_TAG="true"
fi

if [[ "$MONGO_EXPOSED" != "true" ]]
then
  MONGO_EXPOSED="false"
fi

if [[ "$METRICS" != "true" ]]
then
  METRICS="false"
fi

if [[ "$AGENT_NODES" != "true" ]]
then
  AGENT_NODES="false"
fi

if [[ "$CL_DOCKER_NODES" != "true" ]]
then
  CL_DOCKER_NODES="false"
fi

if [[ "$ALLOW_EGR_INK8S" != "true" ]]
then
  ALLOW_EGR_INK8S="false"
fi

if [[ "$DEPLOY_NFS" != "true" ]]
then
  DEPLOY_NFS="false"
else
  RWM_SC="${NAMESPACE_NAME}-nfs"
fi

if ! [ -z "${AGENT_RES}" ]
then
  REQ_RESOURCES="false"
fi

# HOSTNAME=`hostname` ssh-keygen -t rsa -C "code-layer-service" -f "$BASE_PATH/cl_ssh_key" -P "" && cat ${BASE_PATH}/cl_ssh_key.pub
# CODE_LAYER_SSH_KEY=$(cat "$BASE_PATH/cl_ssh_key")
# CODE_LAYER_SSH_KEY_PUB=$(cat "$BASE_PATH/cl_ssh_key.pub")
# rm "$BASE_PATH/cl_ssh_key.pub" "$BASE_PATH/cl_ssh_key"


### Kubernetes namespace creation

kubectl create namespace ${NAMESPACE_NAME} --dry-run=client -o yaml | kubectl apply -f -
if kubectl get secret platform-env-secret -n ${NAMESPACE_NAME} > /dev/null 2>&1
then
  echo "Cleanup old Kaholo deployment in ${NAMESPACE_NAME} namespace before deploying the new one!"
  exit 5
fi

### Secrets preparation

MQ_HOST="rabbitmq"
MQ_PORT="5672"
MQ_PASSWORD_ERLANG_COOKIE=$(tr -dc A-Za-z0-9 </dev/urandom | head -c 30 ; echo '')
MQ_PASSWORD_ADMIN=$(tr -dc A-Za-z0-9 </dev/urandom | head -c 30 ; echo '')
MQ_PASSWORD_BIGBIRD=$(tr -dc A-Za-z0-9 </dev/urandom | head -c 30 ; echo '')
MQ_PASSWORD_TWIDDLEBUG=$(tr -dc A-Za-z0-9 </dev/urandom | head -c 30 ; echo '')
MQ_PASSWORD_CM=$(tr -dc A-Za-z0-9 </dev/urandom | head -c 30 ; echo '')

INT_RABBITMQ_ENABLED="true"
ALLOW_TRAFFIC_TO_K8S_RABBITMQ="false"
if ! [ -z "${EXT_RABBITMQ}" ]
then
  INT_RABBITMQ_ENABLED="false"
  ALLOW_TRAFFIC_TO_K8S_RABBITMQ="true"
  IFS=',' read -ra ADDR <<< "$EXT_RABBITMQ"
  MQ_URL="${ADDR[0]}"
  MQ_ADMIN_USERNAME="${ADDR[1]}"
  MQ_ADMIN_PASSWORD="${ADDR[2]}"
  MQ_HOST="${ADDR[3]}"
  MQ_PORT="${ADDR[4]}"
  MQ_HOST_EXT="${ADDR[5]}"
  MQ_PORT_EXT="${ADDR[6]}"
  MQ_SCHEMA_EXT="${ADDR[7]}"
  ./helpers/TENANT_INIT_RABBITMQ.sh "$MQ_URL" "$MQ_ADMIN_USERNAME" "$MQ_ADMIN_PASSWORD" "$MQ_PASSWORD_BIGBIRD" "$MQ_PASSWORD_TWIDDLEBUG" "$MQ_PASSWORD_CM" "$NAMESPACE_NAME"
fi

RABBITMQ_PREFIX=""
if [[ "$INT_RABBITMQ_ENABLED" == "false" ]]
then
  RABBITMQ_PREFIX="${NAMESPACE_NAME}_"
fi

AMQP_URI_BIGBIRD_RESULTS="amqp://${RABBITMQ_PREFIX}platform:${MQ_PASSWORD_BIGBIRD}@${MQ_HOST}:${MQ_PORT}/${RABBITMQ_PREFIX}results"
AMQP_URI_BIGBIRD_ACTIONS="amqp://${RABBITMQ_PREFIX}platform:${MQ_PASSWORD_BIGBIRD}@${MQ_HOST}:${MQ_PORT}/${RABBITMQ_PREFIX}actions"
AMQP_URI_BIGBIRD_EVENTS="amqp://${RABBITMQ_PREFIX}platform:${MQ_PASSWORD_BIGBIRD}@${MQ_HOST}:${MQ_PORT}/${RABBITMQ_PREFIX}events"

AMQP_URI_TWIDDLEBUG_RESULTS="amqp://${RABBITMQ_PREFIX}agent:${MQ_PASSWORD_TWIDDLEBUG}@${MQ_HOST}:${MQ_PORT}/${RABBITMQ_PREFIX}results"
AMQP_URI_TWIDDLEBUG_ACTIONS="amqp://${RABBITMQ_PREFIX}agent:${MQ_PASSWORD_TWIDDLEBUG}@${MQ_HOST}:${MQ_PORT}/${RABBITMQ_PREFIX}actions"

AMQP_URI_CM_RESULTS="amqp://${RABBITMQ_PREFIX}service:${MQ_PASSWORD_CM}@${MQ_HOST}:${MQ_PORT}/${RABBITMQ_PREFIX}results"
AMQP_URI_CM_ACTIONS="amqp://${RABBITMQ_PREFIX}service:${MQ_PASSWORD_CM}@${MQ_HOST}:${MQ_PORT}/${RABBITMQ_PREFIX}actions"
AMQP_URI_CM_EVENTS="amqp://${RABBITMQ_PREFIX}service:${MQ_PASSWORD_CM}@${MQ_HOST}:${MQ_PORT}/${RABBITMQ_PREFIX}events"

AMQP_URI_DA_TWIDDLEBUG_RESULTS="${MQ_SCHEMA_EXT}://${RABBITMQ_PREFIX}agent:${MQ_PASSWORD_TWIDDLEBUG}@${MQ_HOST_EXT}:${MQ_PORT_EXT}/${RABBITMQ_PREFIX}results"
AMQP_URI_DA_TWIDDLEBUG_ACTIONS="${MQ_SCHEMA_EXT}://${RABBITMQ_PREFIX}agent:${MQ_PASSWORD_TWIDDLEBUG}@${MQ_HOST_EXT}:${MQ_PORT_EXT}/${RABBITMQ_PREFIX}actions"



MONGODB_KAHOLO_PASSWORD=$(tr -dc A-Za-z0-9 </dev/urandom | head -c 30 ; echo '')
MONGODB_ROOT_PASSWORD=$(tr -dc A-Za-z0-9 </dev/urandom | head -c 30 ; echo '')
MONGO_URI="mongodb://kaholo:${MONGODB_KAHOLO_PASSWORD}@mongodb-0.mongodb-headless:27017,mongodb-1.mongodb-headless:27017"


REDIS_SCHEMA="redis://"
REDIS_HOST="redis-master"
REDIS_PORT="6379"
REDIS_USERNAME="default"
REDIS_PASSWORD=$(tr -dc A-Za-z0-9 </dev/urandom | head -c 30 ; echo '')

INT_REDIS_ENABLED="true"
INT_CL_DOCKER_DAEMON_ENABLED="true"
if ! [ -z "${EXT_REDIS}" ]
then
  INT_REDIS_ENABLED="false"
  INT_CL_DOCKER_DAEMON_ENABLED="false"
  IFS=',' read -ra ADDR <<< "$EXT_REDIS"
  REDIS_SCHEMA="${ADDR[0]}"
  REDIS_USERNAME="${ADDR[1]}"
  REDIS_PASSWORD="${ADDR[2]}"
  REDIS_HOST="${ADDR[3]}"
  REDIS_PORT="${ADDR[4]}"
fi

REDIS_URI="${REDIS_SCHEMA}${REDIS_USERNAME}:${REDIS_PASSWORD}@${REDIS_HOST}:${REDIS_PORT}"


if [[ "$INT_RABBITMQ_ENABLED" == "true" ]]
then
  kubectl create secret generic rabbitmq-password --from-literal=rabbitmq-password=${MQ_PASSWORD_ADMIN} -n ${NAMESPACE_NAME}
  kubectl create secret generic rabbitmq-erlang-cookie --from-literal=rabbitmq-erlang-cookie=${MQ_PASSWORD_ERLANG_COOKIE} -n ${NAMESPACE_NAME}
fi
kubectl create secret generic mongodb-secret \
    --from-literal=mongodb-passwords="${MONGODB_KAHOLO_PASSWORD}" \
    --from-literal=mongodb-root-password=${MONGODB_ROOT_PASSWORD} \
    --from-literal=mongodb-metrics-password=${MONGODB_ROOT_PASSWORD} \
    --from-literal=mongodb-replica-set-key=${MONGODB_ROOT_PASSWORD} \
    -n ${NAMESPACE_NAME}
kubectl create secret generic redis-password --from-literal=redis-password=${REDIS_PASSWORD} -n ${NAMESPACE_NAME}

tee ${BASE_PATH}/config > /dev/null <<EOT
export LICENSE_PUBLIC_KEY='${LICENSE_PUBLIC_KEY}'
export DB_URI='${MONGO_URI}'
export SERVER_KEY='${SERVER_KEY}'
export REDIS_URL='${REDIS_URI}'
export AMQP_URI_RESULTS='${AMQP_URI_BIGBIRD_RESULTS}'
export AMQP_URI_ACTIONS='${AMQP_URI_BIGBIRD_ACTIONS}'
export AMQP_URI_EVENTS='${AMQP_URI_BIGBIRD_EVENTS}'
export GITHUB_OAUTH_CLIENT_ID='TODO'
export GITHUB_OAUTH_CLIENT_SECRET='TODO'
EOT
kubectl create secret generic platform-env-secret --from-file ${BASE_PATH}/config -n ${NAMESPACE_NAME}
rm ${BASE_PATH}/config

tee ${BASE_PATH}/config > /dev/null <<EOT
export DB_URI='${MONGO_URI}'
export REDIS_URL='${REDIS_URI}'
export SERVER_KEY='${SERVER_KEY}'
export AMQP_URI_RESULTS='${AMQP_URI_CM_RESULTS}'
export AMQP_URI_ACTIONS='${AMQP_URI_CM_ACTIONS}'
export AMQP_URI_EVENTS='${AMQP_URI_CM_EVENTS}'
EOT
kubectl create secret generic service-env-secret --from-file ${BASE_PATH}/config -n ${NAMESPACE_NAME}
rm ${BASE_PATH}/config

tee ${BASE_PATH}/config > /dev/null <<EOT
export AMQP_URI_RESULTS='${AMQP_URI_TWIDDLEBUG_RESULTS}'
export AMQP_URI_ACTIONS='${AMQP_URI_TWIDDLEBUG_ACTIONS}'
EOT
kubectl create secret generic agent-env-secret --from-file ${BASE_PATH}/config -n ${NAMESPACE_NAME}
rm ${BASE_PATH}/config

tee ${BASE_PATH}/config > /dev/null <<EOT
export DYNAMIC_AGENT_AMQP_URI_RESULTS='${AMQP_URI_DA_TWIDDLEBUG_RESULTS}'
export DYNAMIC_AGENT_AMQP_URI_ACTIONS='${AMQP_URI_DA_TWIDDLEBUG_ACTIONS}'
EOT
kubectl create secret generic dynamic-agents-uris --from-file ${BASE_PATH}/config -n ${NAMESPACE_NAME}
rm ${BASE_PATH}/config

# tee ${BASE_PATH}/code-layer-ssh-key.pem > /dev/null <<EOT
# ${CODE_LAYER_SSH_KEY}
# EOT
# kubectl create secret generic code-layer-ssh-key-secret --from-file ${BASE_PATH}/code-layer-ssh-key.pem -n ${NAMESPACE_NAME}
# rm ${BASE_PATH}/code-layer-ssh-key.pem

if [[ "$INT_RABBITMQ_ENABLED" == "true" ]]
then
  tee ${BASE_PATH}/load_definition.json > /dev/null <<EOT
{"bindings":[],"exchanges":[],"global_parameters":[],"parameters":[],"permissions":[{"configure":".*","read":".*","user":"admin","vhost":"results","write":".*"},{"configure":".*","read":".*","user":"admin","vhost":"actions","write":".*"},{"configure":".*","read":".*","user":"admin","vhost":"events","write":".*"},{"configure":".*","read":"","user":"platform","vhost":"actions","write":".*"},{"configure":".*","read":".*","user":"platform","vhost":"results","write":""},{"configure":".*","read":".*","user":"platform","vhost":"events","write":".*"},{"configure":".*","read":".*","user":"agent","vhost":"actions","write":""},{"configure":".*","read":"","user":"agent","vhost":"results","write":".*"},{"configure":".*","read":"","user":"service","vhost":"actions","write":".*"},{"configure":".*","read":".*","user":"service","vhost":"results","write":""},{"configure":".*","read":".*","user":"service","vhost":"events","write":".*"}],"users":[{"name":"admin","password":"${MQ_PASSWORD_ADMIN}","tags":"administrator"},{"name":"platform","password":"${MQ_PASSWORD_BIGBIRD}","tags":""},{"name":"agent","password":"${MQ_PASSWORD_TWIDDLEBUG}","tags":""},{"name":"service","password":"${MQ_PASSWORD_CM}","tags":""}],"vhosts":[{"limits":[],"metadata":{"description":"","tags":[]},"name":"results"},{"limits":[],"metadata":{"description":"","tags":[]},"name":"actions"},{"limits":[],"metadata":{"description":"","tags":[]},"name":"events"}]}
EOT
  kubectl create secret generic rabbitmq-load-definition --from-file ${BASE_PATH}/load_definition.json -n ${NAMESPACE_NAME}
  rm ${BASE_PATH}/load_definition.json
fi

if [[ "$COPY_SECRETS" == "true" ]]
then
  kubectl get secret regcred --namespace=shd -o yaml | sed "s/namespace: .*/namespace: ${NAMESPACE_NAME}/" | kubectl apply -f -
  kubectl get secret wildcard-certificate --namespace=shd -o yaml | sed "s/namespace: .*/namespace: ${NAMESPACE_NAME}/" | kubectl apply -f -
  kubectl get secret backups-uploader-private-key --namespace=shd -o yaml | sed "s/namespace: .*/namespace: ${NAMESPACE_NAME}/" | kubectl apply -f -
  kubectl get secret dockerhub-auth --namespace=shd -o yaml | sed "s/namespace: .*/namespace: ${NAMESPACE_NAME}/" | kubectl apply -f -
  kubectl get secret dynamic-agents --namespace=shd -o yaml | sed "s/namespace: .*/namespace: ${NAMESPACE_NAME}/" | kubectl apply -f -
fi


## Helm

VALUES_FILE_NAME="values-${NAMESPACE_NAME}.yaml"
VALUES_FILE_PATH="${BASE_PATH}/${VALUES_FILE_NAME}"
rm $VALUES_FILE_PATH > /dev/null &2>1

tee -a ${VALUES_FILE_PATH} > /dev/null <<EOT

global:
  tenantName: ${NAMESPACE_NAME}
  tenantSubdomain: ${SUBDOMAIN}
  domainName: ${DOMAIN}
  showGithubSsoBtn: false
  imageTag: ${KAH_TAG}
  forceGlobalImageTag: ${FORCE_GLOBAL_IMAGE_TAG}
  dynamicAgents: ${DYNAMIC_AGENTS}

quota:
  enabled: ${REQ_RESOURCES}

backups:
  enabled: ${BACKUPS}
  externalStorage:
    gcs:
      enabled: ${BACKUPS_EXT}
      bucketName: ${BACKUPS_BUCKET}
  mongo:
    storage:
      storageClassName: ${RWM_SC}
  plugins:
    storage:
      storageClassName: ${RWM_SC}
  storage:
    storage:
      storageClassName: ${RWM_SC}

networkPolicy:
  allowPotentialCommandInjectionK8S: ${ALLOW_EGR_INK8S}
  allowAgentTrafficToK8SIngressNginx: true
  allowAgentTrafficToK8SRabbitMQ: ${ALLOW_TRAFFIC_TO_K8S_RABBITMQ}

integrations:
  gtmContainerID:
  sendGrigApiKey:
  rudderstackWriteKey:
  rudderStackUrl:
  configurationsVideoId: KZt9OyQecDo
  pipelinesVideoId: UK6fHGs0Jr0
  firebaseApiKey: AIzaSyA4BiUvd9tyw2iuK6KMVSiIm9xlt8q4a5U
  firebaseAuthDomain: kaholo-saas-repos.firebaseapp.com
  firebaseProjectId: kaholo-saas-repos
  firebaseStorageBucket: kaholo-saas-repos.appspot.com
  firebaseMessageSenderId: "533560841432"
  firebaseAppId: "1:533560841432:web:687a57c5d240ca3d2133ad"
  artifactoryUrl: https://arti.kaholo.net/artifactory/
  artifactoryRepo: plugins-prd
  artifactoryUsername: bigbird
  artifactoryPassword: eyJ2ZXIiOiIyIiwidHlwIjoiSldU$
  dynamicAgentsDockerhubNamespace:
  dynamicAgentsDockerhubReposPrefix:
  dynamicAgentsDockerhubDefaultImageTag: latest

images:
  repoNamePrefix: ${REGISTRY}
EOT

if [[ "$REQ_RESOURCES" == "true" ]]
then
tee -a ${VALUES_FILE_PATH} > /dev/null <<EOT
actionExecutionService:
  resources:
    limits:
      memory: "1024Mi"
      cpu: "200m"
    requests:
      memory: "50Mi"
      cpu: "5m"

agentsManagerService:
  resources:
    limits:
      memory: "1024Mi"
      cpu: "200m"
    requests:
      memory: "50Mi"
      cpu: "5m"

codeLayerService:
  resources:
    limits:
      cpu: "200m"
      memory: "1024Mi"
    requests:
      cpu: "5m"
      memory: "50Mi"

EOT
fi

tee -a ${VALUES_FILE_PATH} > /dev/null <<EOT
clDockerDaemon: 
  enabled: ${INT_CL_DOCKER_DAEMON_ENABLED}
  dedicatedNodeGroups: ${CL_DOCKER_NODES}
  docker:
    storage:
      storageClassName: ${RWO_SC}
EOT

if [[ "$REQ_RESOURCES" == "true" ]]
then
tee -a ${VALUES_FILE_PATH} > /dev/null <<EOT
  resources:
    limits:
      cpu: "1000m"
      memory: "2048Mi"
    requests:
      cpu: "50m"
      memory: "256Mi"
  sidecar:
    resources:
      limits:
        cpu: 50m
        memory: 256Mi
      requests:
        cpu: 5m
        memory: 50Mi

errorService:
  resources:
    limits:
      memory: "1024Mi"
      cpu: "200m"
    requests:
      memory: "50Mi"
      cpu: "5m"

flowControlService:
  resources:
    limits:
      cpu: "200m"
      memory: "1024Mi"
    requests:
      cpu: "5m"
      memory: "50Mi"

websocketService:
  resources:
    limits:
      memory: "1024Mi"
      cpu: "200m"
    requests:
      memory: "50Mi"
      cpu: "5m"

mongoService:
  resources:
    limits:
      cpu: "200m"
      memory: "1024Mi"
    requests:
      cpu: "5m"
      memory: "50Mi"

pipelineExecutionService:
  resources:
    limits:
      memory: "1024Mi"
      cpu: "200m"
    requests:
      memory: "50Mi"
      cpu: "5m"

queuesService:
  resources:
    limits:
      memory: "1024Mi"
      cpu: "200m"
    requests:
      memory: "50Mi"
      cpu: "5m"

schedulerService:
  resources:
    limits:
      memory: "1024Mi"
      cpu: "200m"
    requests:
      memory: "50Mi"
      cpu: "5m"

stateService:
  resources:
    limits:
      memory: "1024Mi"
      cpu: "200m"
    requests:
      memory: "50Mi"
      cpu: "5m"

storageService:
  platformSidecar: false
  resources:
    limits:
      memory: "1024Mi"
      cpu: "200m"
    requests:
      memory: "50Mi"
      cpu: "5m"
EOT
fi

tee -a ${VALUES_FILE_PATH} > /dev/null <<EOT
platform:
  plugins:
    storage:
      storageClassName: ${RWM_SC}
  pluginscdn:
    storage:
      storageClassName: ${RWM_SC}
  storage:
    storage:
      storageClassName: ${RWM_SC}
EOT

if [[ "$REQ_RESOURCES" == "true" ]]
then
tee -a ${VALUES_FILE_PATH} > /dev/null <<EOT
  resources:
    limits:
      cpu: "500m"
      memory: "1024Mi"
    requests:
      cpu: "50m"
      memory: "128Mi"
EOT
fi

tee -a ${VALUES_FILE_PATH} > /dev/null <<EOT
  ingress:
    enabled: true
    tls:
      host: "*.${DOMAIN}"
      secretName: ${INGRESS_SECRET}
  migrations:
EOT

if [[ "$REQ_RESOURCES" == "true" ]]
then
tee -a ${VALUES_FILE_PATH} > /dev/null <<EOT
    job:
      resources:
        limits:
          cpu: "1"
          memory: "2Gi"
        requests:
          cpu: "100m"
          memory: "128Mi"
EOT
fi

tee -a ${VALUES_FILE_PATH} > /dev/null <<EOT
    storage:
      storageClassName: ${RWM_SC}

agent:
  agentKey: ${AGENT_KEY}
  dedicatedNodeGroups: ${AGENT_NODES}
  plugins:
    storage:
      storageClassName: ${RWO_SC}
  docker:
    storage:
      storageClassName: ${RWO_SC}
EOT

if [[ "$REQ_RESOURCES" == "true" ]]
then
tee -a ${VALUES_FILE_PATH} > /dev/null <<EOT
  resources:
    limits:
      cpu: "4"
      memory: "8Gi"
    requests:
      cpu: "300m"
      memory: "2Gi"
EOT
elif ! [ -z "${AGENT_RES}" ]
then
tee -a ${VALUES_FILE_PATH} > /dev/null <<EOT
  resources:
    limits:
      cpu: "$(printf $AGENT_RES | jq -r '.limits.cpu')"
      memory: "$(printf $AGENT_RES | jq -r '.limits.memory')"
    requests:
      cpu: "$(printf $AGENT_RES | jq -r '.requests.cpu')"
      memory: "$(printf $AGENT_RES | jq -r '.requests.memory')"
EOT
fi

tee -a ${VALUES_FILE_PATH} > /dev/null <<EOT
mongodb:
  persistence:
    storageClass: ${RWO_SC}
  serviceAccount:
    create: ${MONGO_EXPOSED}
  rbac:
    create: ${MONGO_EXPOSED}
  externalAccess:
    enabled: ${MONGO_EXPOSED}
    autoDiscovery:
      enabled: ${MONGO_EXPOSED}
EOT

if [[ "$REQ_RESOURCES" == "true" ]]
then
tee -a ${VALUES_FILE_PATH} > /dev/null <<EOT
      resources:
        limits:
          cpu: 100m
          memory: 256Mi
        requests:
          cpu: 10m
          memory: 32Mi
  resources:
    limits:
       cpu: 1000m
       memory: 4Gi
    requests:
       cpu: 10m
       memory: 256Mi
  arbiter:
    resources:
      limits:
        cpu: 200m
        memory: 512Mi
      requests:
        cpu: 50m
        memory: 128Mi
EOT
fi

tee -a ${VALUES_FILE_PATH} > /dev/null <<EOT
  metrics:
    enabled: ${METRICS}
    serviceMonitor:
      enabled: true
      additionalLabels:
        release: monitoring
EOT

if [[ "$REQ_RESOURCES" == "true" ]]
then
tee -a ${VALUES_FILE_PATH} > /dev/null <<EOT
    resources:
      limits:
        cpu: 100m
        memory: 256Mi
      requests:
        cpu: 10m
        memory: 32Mi
EOT
fi

tee -a ${VALUES_FILE_PATH} > /dev/null <<EOT
rabbitmq:
  enabled: ${INT_RABBITMQ_ENABLED}
  persistence:
    storageClass: ${RWO_SC}
  ingress:
    enabled: true
    hostname: ${SUBDOMAIN}-rabbitmq-mgmt.${DOMAIN}
    ingressClassName: nginx
    extraTls:
    - hosts:
      - "*.${DOMAIN}"
      secretName: # wildcard-certificate
  metrics:
    enabled: ${METRICS}
    serviceMonitor:
      enabled: true
      labels:
        release: monitoring
EOT

if [[ "$REQ_RESOURCES" == "true" ]]
then
tee -a ${VALUES_FILE_PATH} > /dev/null <<EOT
    resources:
      limits:
        cpu: 100m
        memory: 256Mi
      requests:
        cpu: 10m
        memory: 32Mi
  resources:
    limits:
       cpu: 4000m
       memory: 4Gi
    requests:
       cpu: 200m
       memory: 256Mi
EOT
fi

tee -a ${VALUES_FILE_PATH} > /dev/null <<EOT
redis:
  enabled: ${INT_REDIS_ENABLED}
  global:
    storageClass: ${RWO_SC}
EOT

if [[ "$REQ_RESOURCES" == "true" ]]
then
tee -a ${VALUES_FILE_PATH} > /dev/null <<EOT
  master:
    resources:
      limits:
        cpu: 100m
        memory: 512Mi
      requests:
        cpu: 5m
        memory: 50Mi
  replica:
    resources:
      limits:
        cpu: 100m
        memory: 512Mi
      requests:
        cpu: 5m
        memory: 50Mi
EOT
fi

tee -a ${VALUES_FILE_PATH} > /dev/null <<EOT
  metrics:
    enabled: ${METRICS}
EOT

if [[ "$REQ_RESOURCES" == "true" ]]
then
tee -a ${VALUES_FILE_PATH} > /dev/null <<EOT
    resources:
      limits:
        cpu: 100m
        memory: 256Mi
      requests:
        cpu: 10m
        memory: 32Mi
EOT
fi

tee -a ${VALUES_FILE_PATH} > /dev/null <<EOT
    serviceMonitor:
      enabled: true
      additionalLabels:
        release: monitoring

nfs-server-provisioner:
  enabled: ${DEPLOY_NFS}
  persistence:
    enabled: true
    storageClass: ${RWO_SC}
  storageClass:
    name: ${NAMESPACE_NAME}-nfs
EOT

if [[ "$REQ_RESOURCES" == "true" ]]
then
tee -a ${VALUES_FILE_PATH} > /dev/null <<EOT
  resources:
    limits:
      cpu: 1000m
      memory: 1024Mi
    requests:
      cpu: 100m
      memory: 128Mi
EOT
fi

# helm diff upgrade ${NAMESPACE_NAME} ${BASE_PATH} -n ${NAMESPACE_NAME} -f ${VALUES_FILE_PATH}
helm install ${NAMESPACE_NAME} ${BASE_PATH} -n ${NAMESPACE_NAME} --create-namespace -f ${VALUES_FILE_PATH}

echo "
Templated values.yaml content for this installation:
$(cat ${VALUES_FILE_PATH})

---
"

echo "
Use below command to do future updates by changing config in ${VALUES_FILE_NAME} file:
helm upgrade ${NAMESPACE_NAME} . -n ${NAMESPACE_NAME} -f ${VALUES_FILE_NAME} --description \"description\"

To see only the diff of changes that will be made, you can use Helm Diff Plugin (https://github.com/databus23/helm-diff):
helm diff upgrade ${NAMESPACE_NAME} . -n ${NAMESPACE_NAME} -f ${VALUES_FILE_NAME}

Remember to save your file ${VALUES_FILE_NAME}, it's a configuration of your Kaholo instance :)
"

# rm ${VALUES_FILE_PATH}
