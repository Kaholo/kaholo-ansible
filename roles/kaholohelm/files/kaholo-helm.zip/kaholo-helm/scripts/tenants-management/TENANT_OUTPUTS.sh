#!/bin/bash
set -e  # Exit immediately if a command exits with a non-zero status
set -o pipefail # Causes a pipeline to return the exit status of the last command in the pipe that returned a non-zero return value
HOME_DIR=$(pwd)

NAMESPACE_NAME=$1
DOMAIN_NAME=$2
TENANT_SUBDOMAIN=$3
RABBITMQ_URL=$4

if kubectl get svc mongodb-0-external -n $NAMESPACE_NAME > /dev/null 2>&1
then
    DB_NAME="kaholo"
    MONGO_HOST1=""; while [ -z $MONGO_HOST1 ]; do echo "Waiting for the endpoint..."; MONGO_HOST1=$(kubectl get svc mongodb-0-external -n ${NAMESPACE_NAME} --template="{{range .status.loadBalancer.ingress}}{{.ip}}{{end}}"); [ -z "$MONGO_HOST1" ] && sleep 10; done; echo "End point ready-" && echo $MONGO_HOST1;
    MONGO_HOST2=""; while [ -z $MONGO_HOST2 ]; do echo "Waiting for the endpoint..."; MONGO_HOST2=$(kubectl get svc mongodb-1-external -n ${NAMESPACE_NAME} --template="{{range .status.loadBalancer.ingress}}{{.ip}}{{end}}"); [ -z "$MONGO_HOST2" ] && sleep 10; done; echo "End point ready-" && echo $MONGO_HOST2;
    MONGO_HOST="${MONGO_HOST1}:27017,${MONGO_HOST2}"
    MONGO_URI="$(kubectl get secret platform-env-secret -o jsonpath="{.data.config}" -n $NAMESPACE_NAME | base64 -d | grep DB_URI | sed -E "s/mongodb-0.*/${MONGO_HOST}/" | sed "s/export DB_URI='//")/${DB_NAME}"
elif ! kubectl get statefulset mongodb -n $NAMESPACE_NAME > /dev/null 2>&1 && kubectl get svc mongodb-0-external -n mongodb > /dev/null 2>&1
then
    DB_NAME="${NAMESPACE_NAME}"
    MONGO_HOST1=""; while [ -z $MONGO_HOST1 ]; do echo "Waiting for the endpoint..."; MONGO_HOST1=$(kubectl get svc mongodb-0-external -n mongodb --template="{{range .status.loadBalancer.ingress}}{{.ip}}{{end}}"); [ -z "$MONGO_HOST1" ] && sleep 10; done; echo "End point ready-" && echo $MONGO_HOST1;
    MONGO_HOST2=""; while [ -z $MONGO_HOST2 ]; do echo "Waiting for the endpoint..."; MONGO_HOST2=$(kubectl get svc mongodb-1-external -n mongodb --template="{{range .status.loadBalancer.ingress}}{{.ip}}{{end}}"); [ -z "$MONGO_HOST2" ] && sleep 10; done; echo "End point ready-" && echo $MONGO_HOST2;
    MONGO_HOST3=""; while [ -z $MONGO_HOST3 ]; do echo "Waiting for the endpoint..."; MONGO_HOST3=$(kubectl get svc mongodb-2-external -n mongodb --template="{{range .status.loadBalancer.ingress}}{{.ip}}{{end}}"); [ -z "$MONGO_HOST3" ] && sleep 10; done; echo "End point ready-" && echo $MONGO_HOST3;
    MONGO_HOST="${MONGO_HOST1}:27017,${MONGO_HOST2},${MONGO_HOST3}:27017"
    MONGO_URI="$(kubectl get secret platform-env-secret -o jsonpath="{.data.config}" -n $NAMESPACE_NAME | base64 -d | grep DB_URI | sed -E "s/mongodb-0.*/${MONGO_HOST}/" | sed "s/export DB_URI='//")/${DB_NAME}"
else
    MONGO_URI="\nNot exposed outside of the cluster. You need to use kubectl port-forward: 'kubectl port-forward pod/mongodb-0 27017:27017 -n mongodb' and 'kubectl port-forward pod/mongodb-1 27018:27017 -n mongodb' in two separate terminals and then connect to '$(kubectl get secret platform-env-secret -o jsonpath="{.data.config}" -n $NAMESPACE_NAME | base64 -d | grep DB_URI | sed -E "s/mongodb-0.*/localhost:27017,localhost:27018/" | sed "s/export DB_URI='//")/${NAMESPACE_NAME}?ssl=false&retryWrites=true'"
fi
RABBITMQ_PASSWORD=$(helm get values rabbitmq -n rabbitmq | grep password | awk '$2 {print$2}')

printf "
Your tenant will be available here: https://${TENANT_SUBDOMAIN}.${DOMAIN_NAME}

You can use below data to access necessary services for debugging purposes

Mongo URI:         $MONGO_URI
MQ URL:            $RABBITMQ_URL
MQ login data:     admin / ${RABBITMQ_PASSWORD}

If you want to access Kuberentes resources or Redis please contact with Devops Engineer

"
