#!/bin/bash -
set -e  # Exit immediately if a command exits with a non-zero status
set -o pipefail # Causes a pipeline to return the exit status of the last command in the pipe that returned a non-zero return value


NAMESPACE_NAME=$1
VAULT_TOKEN=$2
VAULT_ADDR=$3


cat <<EOF | kubectl apply -n default -f  -
apiVersion: v1
kind: Pod
metadata:
  name: vault-helper-${NAMESPACE_NAME}
spec:
  containers:
  - name: vault-helper
    image: vault:1.13.3
    args:
      ['sh', '-c', 'sleep 600']
    env:
    - name: VAULT_ADDR
      value: ${VAULT_ADDR}
    volumeMounts:
    - name: vault-ha-cacrt
      mountPath: /etc/ssl/certs/ca.crt
      subPath: ca.crt
      readOnly: false
    resources:
      limits:
        cpu: 500m
        memory: 512Mi
      requests:
        cpu: 100m
        memory: 128Mi
  volumes:
  - name: vault-ha-cacrt
    secret:
      secretName: vault-ha-cacrt
EOF

kubectl wait --for=condition=ready pod vault-helper-${NAMESPACE_NAME} -n default --timeout 600s
sleep 20

kubectl exec -n default -ti vault-helper-${NAMESPACE_NAME} -- vault login -no-print $VAULT_TOKEN

kubectl exec -n default -ti vault-helper-${NAMESPACE_NAME} -- vault delete rabbitmq/roles/${NAMESPACE_NAME}-platform

kubectl exec -n default -ti vault-helper-${NAMESPACE_NAME} -- vault delete rabbitmq/roles/${NAMESPACE_NAME}-service

kubectl exec -n default -ti vault-helper-${NAMESPACE_NAME} -- vault delete rabbitmq/roles/${NAMESPACE_NAME}-agent

kubectl exec -n default -ti vault-helper-${NAMESPACE_NAME} -- vault delete db/roles/${NAMESPACE_NAME}-redis

kubectl exec -n default -ti vault-helper-${NAMESPACE_NAME} -- vault delete db/roles/${NAMESPACE_NAME}-mongodb

kubectl exec -n default -ti vault-helper-${NAMESPACE_NAME} -- vault policy delete auth-policy-${NAMESPACE_NAME}

kubectl exec -n default -ti vault-helper-${NAMESPACE_NAME} -- vault delete auth/k8s-auth-mount/role/${NAMESPACE_NAME}-auth-role-operator

kubectl exec -n default -ti vault-helper-${NAMESPACE_NAME} -- vault delete auth/k8s-auth-mount/role/${NAMESPACE_NAME}-auth-role

kubectl delete pod vault-helper-${NAMESPACE_NAME} -n default
