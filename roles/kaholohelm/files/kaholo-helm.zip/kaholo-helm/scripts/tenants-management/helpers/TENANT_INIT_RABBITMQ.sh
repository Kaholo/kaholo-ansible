#!/bin/bash -
set -e  # Exit immediately if a command exits with a non-zero status
set -o pipefail # Causes a pipeline to return the exit status of the last command in the pipe that returned a non-zero return value

MQ_URL=$1
MQ_USERNAME_ADMIN=$2
MQ_PASSWORD_ADMIN=$3
MQ_PASSWORD_BIGBIRD=$4
MQ_PASSWORD_TWIDDLEBUG=$5
MQ_PASSWORD_CM=$6
NAMESPACE_NAME=$7

if curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XGET ${MQ_URL}/api/vhosts/${NAMESPACE_NAME}_actions > /dev/null
then
  echo "RabbitMQ vhosts exists, clean them up before proceeding"
  exit 5
fi

curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT ${MQ_URL}/api/vhosts/${NAMESPACE_NAME}_actions
curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT ${MQ_URL}/api/vhosts/${NAMESPACE_NAME}_results
curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT ${MQ_URL}/api/vhosts/${NAMESPACE_NAME}_events

if curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XGET -d'{"password":"'$MQ_PASSWORD_BIGBIRD'","tags":""}' ${MQ_URL}/api/users/${NAMESPACE_NAME}_platform > /dev/null
then
  echo "RabbitMQ users exists, clean them up before proceeding"
  exit 5
fi
if curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XGET -d'{"password":"'$MQ_PASSWORD_BIGBIRD'","tags":""}' ${MQ_URL}/api/users/${NAMESPACE_NAME}_agent > /dev/null
then
  echo "RabbitMQ users exists, clean them up before proceeding"
  exit 5
fi
if curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XGET -d'{"password":"'$MQ_PASSWORD_BIGBIRD'","tags":""}' ${MQ_URL}/api/users/${NAMESPACE_NAME}_service > /dev/null
then
  echo "RabbitMQ users exists, clean them up before proceeding"
  exit 5
fi

curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT -d'{"password":"'$MQ_PASSWORD_BIGBIRD'","tags":""}' ${MQ_URL}/api/users/${NAMESPACE_NAME}_platform
curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT -d'{"configure":".*","write":"","read":".*"}' ${MQ_URL}/api/permissions/${NAMESPACE_NAME}_results/${NAMESPACE_NAME}_platform
curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT -d'{"configure":".*","write":".*","read":""}' ${MQ_URL}/api/permissions/${NAMESPACE_NAME}_actions/${NAMESPACE_NAME}_platform
curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT -d'{"configure":".*","write":".*","read":".*"}' ${MQ_URL}/api/permissions/${NAMESPACE_NAME}_events/${NAMESPACE_NAME}_platform
curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT -d'{"password":"'$MQ_PASSWORD_TWIDDLEBUG'","tags":""}' ${MQ_URL}/api/users/${NAMESPACE_NAME}_agent
curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT -d'{"configure":".*","write":".*","read":""}' ${MQ_URL}/api/permissions/${NAMESPACE_NAME}_results/${NAMESPACE_NAME}_agent
curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT -d'{"configure":".*","write":"","read":".*"}' ${MQ_URL}/api/permissions/${NAMESPACE_NAME}_actions/${NAMESPACE_NAME}_agent
curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT -d'{"password":"'$MQ_PASSWORD_CM'","tags":""}' ${MQ_URL}/api/users/${NAMESPACE_NAME}_service
curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT -d'{"configure":".*","write":"","read":".*"}' ${MQ_URL}/api/permissions/${NAMESPACE_NAME}_results/${NAMESPACE_NAME}_service
curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT -d'{"configure":".*","write":".*","read":""}' ${MQ_URL}/api/permissions/${NAMESPACE_NAME}_actions/${NAMESPACE_NAME}_service
curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT -d'{"configure":".*","write":".*","read":".*"}' ${MQ_URL}/api/permissions/${NAMESPACE_NAME}_events/${NAMESPACE_NAME}_service
