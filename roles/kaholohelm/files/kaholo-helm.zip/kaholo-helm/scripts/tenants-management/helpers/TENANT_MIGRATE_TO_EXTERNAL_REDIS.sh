#!/bin/bash -
set -e  # Exit immediately if a command exits with a non-zero status
set -o pipefail # Causes a pipeline to return the exit status of the last command in the pipe that returned a non-zero return value

NAMESPACE_NAME=$1
REDIS_URI=$2
REDIS_URI_ESCAPED="${REDIS_URI//\//\\\/}"


cd ../../../
helm get values $NAMESPACE_NAME -n $NAMESPACE_NAME > values-$NAMESPACE_NAME.yaml
cp values-$NAMESPACE_NAME.yaml values-$NAMESPACE_NAME.yaml_original
sed -i 's/^clDockerDaemon:/clDockerDaemon:\n  enabled: false/g' values-$NAMESPACE_NAME.yaml 
sed -i 's/^redis:/redis:\n  enabled: false/g' values-$NAMESPACE_NAME.yaml 
! diff values-$NAMESPACE_NAME.yaml values-$NAMESPACE_NAME.yaml_original
# helm diff upgrade $NAMESPACE_NAME . -n $NAMESPACE_NAME -f values-$NAMESPACE_NAME.yaml
# exit 1

kubectl get secret platform-env-secret -n $NAMESPACE_NAME -o jsonpath="{.data.config}" | base64 -d > config
cp config config-platform-${NAMESPACE_NAME}
kubectl create secret generic platform-env-secret-old --from-file config -n $NAMESPACE_NAME
sed -iE "s/REDIS_URL='.*'/REDIS_URL='${REDIS_URI_ESCAPED}'/g" config
kubectl delete secret platform-env-secret -n $NAMESPACE_NAME
kubectl create secret generic platform-env-secret --from-file config -n $NAMESPACE_NAME

kubectl get secret service-env-secret -n $NAMESPACE_NAME -o jsonpath="{.data.config}" | base64 -d > config
kubectl create secret generic service-env-secret-old --from-file config -n $NAMESPACE_NAME
cp config config-service-${NAMESPACE_NAME}
sed -iE "s/REDIS_URL='.*'/REDIS_URL='${REDIS_URI_ESCAPED}'/g" config
kubectl delete secret service-env-secret -n $NAMESPACE_NAME
kubectl create secret generic service-env-secret --from-file config -n $NAMESPACE_NAME

helm upgrade $NAMESPACE_NAME . -n $NAMESPACE_NAME -f values-$NAMESPACE_NAME.yaml

kubectl rollout restart deployment -n $NAMESPACE_NAME

kubectl get deploy --no-headers=true -n $NAMESPACE_NAME | awk '$1 {print$1}' | while read vol; do kubectl rollout status deployment $vol --timeout=300s -n $NAMESPACE_NAME; done
