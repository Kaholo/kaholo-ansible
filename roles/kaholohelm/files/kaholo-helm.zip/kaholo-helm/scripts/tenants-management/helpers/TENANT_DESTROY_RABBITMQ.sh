#!/bin/bash -
set -e  # Exit immediately if a command exits with a non-zero status
set -o pipefail # Causes a pipeline to return the exit status of the last command in the pipe that returned a non-zero return value

MQ_URL=$1
MQ_ADMIN_USERNAME=$2
MQ_ADMIN_PASSWORD=$3
NAMESPACE_NAME=$4

curl --fail -s -i -u ${MQ_ADMIN_USERNAME}:${MQ_ADMIN_PASSWORD} -H "content-type:application/json" -XDELETE ${MQ_URL}/api/vhosts/${NAMESPACE_NAME}_actions
curl --fail -s -i -u ${MQ_ADMIN_USERNAME}:${MQ_ADMIN_PASSWORD} -H "content-type:application/json" -XDELETE ${MQ_URL}/api/vhosts/${NAMESPACE_NAME}_results
curl --fail -s -i -u ${MQ_ADMIN_USERNAME}:${MQ_ADMIN_PASSWORD} -H "content-type:application/json" -XDELETE ${MQ_URL}/api/vhosts/${NAMESPACE_NAME}_events
curl --fail -s -i -u ${MQ_ADMIN_USERNAME}:${MQ_ADMIN_PASSWORD} -H "content-type:application/json" -XDELETE ${MQ_URL}/api/users/${NAMESPACE_NAME}_platform
curl --fail -s -i -u ${MQ_ADMIN_USERNAME}:${MQ_ADMIN_PASSWORD} -H "content-type:application/json" -XDELETE ${MQ_URL}/api/users/${NAMESPACE_NAME}_agent
curl --fail -s -i -u ${MQ_ADMIN_USERNAME}:${MQ_ADMIN_PASSWORD} -H "content-type:application/json" -XDELETE ${MQ_URL}/api/users/${NAMESPACE_NAME}_service
