#!/bin/bash -
set -e  # Exit immediately if a command exits with a non-zero status
set -o pipefail # Causes a pipeline to return the exit status of the last command in the pipe that returned a non-zero return value

MQ_URL=$1
MQ_USERNAME_ADMIN=$2
MQ_PASSWORD_ADMIN=$3
NAMESPACE_NAME=$4

curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT ${MQ_URL}/api/vhost-limits/${NAMESPACE_NAME}_actions/max-queues -d '{"value": 500}'
curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT ${MQ_URL}/api/vhost-limits/${NAMESPACE_NAME}_results/max-queues -d '{"value": 500}'
curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT ${MQ_URL}/api/vhost-limits/${NAMESPACE_NAME}_events/max-queues -d '{"value": 2000}'
