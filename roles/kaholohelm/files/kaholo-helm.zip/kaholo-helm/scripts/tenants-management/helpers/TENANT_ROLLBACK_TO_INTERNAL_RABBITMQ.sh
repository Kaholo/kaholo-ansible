#!/bin/bash -
set -e  # Exit immediately if a command exits with a non-zero status
set -o pipefail # Causes a pipeline to return the exit status of the last command in the pipe that returned a non-zero return value

### IMPORTANT:
# Remember to make sure that rabbitmq.enabled is set to true in values.yaml

NAMESPACE_NAME=$1

cd ../../../
helm get values $NAMESPACE_NAME -n $NAMESPACE_NAME > values-$NAMESPACE_NAME.yaml
cp values-$NAMESPACE_NAME.yaml values-$NAMESPACE_NAME.yaml_original_rollback
sed -i 's/  allowAgentTrafficToK8SRabbitMQ: true//g' values-$NAMESPACE_NAME.yaml 
! diff values-$NAMESPACE_NAME.yaml values-$NAMESPACE_NAME.yaml_original_rollback
# helm diff upgrade $NAMESPACE_NAME . -n $NAMESPACE_NAME -f values-$NAMESPACE_NAME.yaml
# exit 1
helm upgrade $NAMESPACE_NAME . -n $NAMESPACE_NAME -f values-$NAMESPACE_NAME.yaml

kubectl get secret platform-env-secret-old -n $NAMESPACE_NAME -o jsonpath="{.data.config}" | base64 -d > config
kubectl delete secret platform-env-secret -n $NAMESPACE_NAME
kubectl create secret generic platform-env-secret --from-file config -n $NAMESPACE_NAME
kubectl delete secret platform-env-secret-old  -n $NAMESPACE_NAME

kubectl get secret service-env-secret-old -n $NAMESPACE_NAME -o jsonpath="{.data.config}" | base64 -d > config
kubectl delete secret service-env-secret -n $NAMESPACE_NAME
kubectl create secret generic service-env-secret --from-file config -n $NAMESPACE_NAME
kubectl delete secret service-env-secret-old -n $NAMESPACE_NAME

kubectl get secret agent-env-secret-old -n $NAMESPACE_NAME -o jsonpath="{.data.config}" | base64 -d > config
kubectl delete secret agent-env-secret -n $NAMESPACE_NAME
kubectl create secret generic agent-env-secret --from-file config -n $NAMESPACE_NAME
kubectl delete secret agent-env-secret-old -n $NAMESPACE_NAME

kubectl rollout restart deployment -n $NAMESPACE_NAME
