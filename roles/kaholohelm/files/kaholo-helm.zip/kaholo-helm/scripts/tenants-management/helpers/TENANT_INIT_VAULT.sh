#!/bin/bash -
set -e  # Exit immediately if a command exits with a non-zero status
set -o pipefail # Causes a pipeline to return the exit status of the last command in the pipe that returned a non-zero return value


NAMESPACE_NAME=$1
VAULT_TOKEN=$2
VAULT_ADDR=$3


cat <<EOF | kubectl apply -n default -f  -
apiVersion: v1
kind: Pod
metadata:
  name: vault-helper-${NAMESPACE_NAME}
spec:
  containers:
  - name: vault-helper
    image: vault:1.13.3
    args:
      ['sh', '-c', 'sleep 600']
    env:
    - name: VAULT_ADDR
      value: ${VAULT_ADDR}
    volumeMounts:
    - name: vault-ha-cacrt
      mountPath: /etc/ssl/certs/ca.crt
      subPath: ca.crt
      readOnly: false
    resources:
      limits:
        cpu: 500m
        memory: 512Mi
      requests:
        cpu: 100m
        memory: 128Mi
  volumes:
  - name: vault-ha-cacrt
    secret:
      secretName: vault-ha-cacrt
EOF

kubectl wait --for=condition=ready pod vault-helper-${NAMESPACE_NAME} -n default --timeout 600s
sleep 10

kubectl exec -n default -ti vault-helper-${NAMESPACE_NAME} -- vault login -no-print $VAULT_TOKEN

kubectl exec -n default -ti vault-helper-${NAMESPACE_NAME} -- vault write rabbitmq/roles/${NAMESPACE_NAME}-platform \
  vhosts='{"'${NAMESPACE_NAME}'_actions":{"configure": ".*", "write": ".*", "read": ""}, "'${NAMESPACE_NAME}'_events":{"configure": ".*", "write": ".*", "read": ".*"}, "'${NAMESPACE_NAME}'_results":{"configure": ".*", "write": "", "read": ".*"}}'

kubectl exec -n default -ti vault-helper-${NAMESPACE_NAME} -- vault write rabbitmq/roles/${NAMESPACE_NAME}-service \
  vhosts='{"'${NAMESPACE_NAME}'_actions":{"configure": ".*", "write": ".*", "read": ""}, "'${NAMESPACE_NAME}'_events":{"configure": ".*", "write": ".*", "read": ".*"}, "'${NAMESPACE_NAME}'_results":{"configure": ".*", "write": "", "read": ".*"}}'

kubectl exec -n default -ti vault-helper-${NAMESPACE_NAME} -- vault write rabbitmq/roles/${NAMESPACE_NAME}-agent \
  vhosts='{"'${NAMESPACE_NAME}'_actions":{"configure": ".*", "write": "", "read": ".*"}, "'${NAMESPACE_NAME}'_results":{"configure": ".*", "write": ".*", "read": ""}}'

kubectl exec -n default -ti vault-helper-${NAMESPACE_NAME} -- vault write db/roles/${NAMESPACE_NAME}-redis \
  db_name="redis" \
  creation_statements='["~'${NAMESPACE_NAME}'*", "~cm*", "&*", "+@all"]' \
  default_ttl="6h" \
  max_ttl="12h"

kubectl exec -n default -ti vault-helper-${NAMESPACE_NAME} -- vault write db/roles/${NAMESPACE_NAME}-mongodb \
   db_name=mongodb \
   creation_statements='{ "db": "'${NAMESPACE_NAME}'", "roles": [{ "role": "readWrite" }] }' \
   revocation_statements='{"db":"'${NAMESPACE_NAME}'"}' \
   name=kaholo-mongodb \
   default_ttl="6h" \
   max_ttl="12h"


kubectl exec -n default -ti vault-helper-${NAMESPACE_NAME} -- vault policy write auth-policy-${NAMESPACE_NAME} - <<EOF
path "db/creds/${NAMESPACE_NAME}-*" {
   capabilities = ["read"]
}
path "rabbitmq/creds/${NAMESPACE_NAME}-*" {
   capabilities = ["read"]
}
EOF

kubectl exec -n default -ti vault-helper-${NAMESPACE_NAME} -- vault write auth/k8s-auth-mount/role/${NAMESPACE_NAME}-auth-role-operator \
   bound_service_account_names=default \
   bound_service_account_namespaces=vault-secrets-operator \
   token_ttl=0 \
   token_period=120 \
   token_policies="auth-policy-${NAMESPACE_NAME}" \
   audience=vault

kubectl exec -n default -ti vault-helper-${NAMESPACE_NAME} -- vault write auth/k8s-auth-mount/role/${NAMESPACE_NAME}-auth-role \
   bound_service_account_names=default \
   bound_service_account_namespaces="${NAMESPACE_NAME}" \
   token_ttl=0 \
   token_period=120 \
   token_policies="auth-policy-${NAMESPACE_NAME}" \
   audience=vault

kubectl delete pod vault-helper-${NAMESPACE_NAME} -n default
