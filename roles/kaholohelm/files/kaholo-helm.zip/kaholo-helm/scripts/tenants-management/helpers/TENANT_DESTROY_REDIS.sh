#!/bin/bash -
set -e  # Exit immediately if a command exits with a non-zero status
set -o pipefail # Causes a pipeline to return the exit status of the last command in the pipe that returned a non-zero return value


NAMESPACE_NAME=$1
REDIS_URI=$2
REDIS_KEY_PREFIX="${NAMESPACE_NAME}*"


cat <<EOF | kubectl apply -n ${NAMESPACE_NAME} -f  -
apiVersion: v1
kind: ConfigMap
metadata:
  name: redis-cleanup
data:
  redis-cleanup.py: |
    import redis
    import os
    i=0
    conn = redis.from_url('${REDIS_URI}')
    try:
        print('Removing keys with prefix ${REDIS_KEY_PREFIX}')
        for key in conn.scan_iter('${REDIS_KEY_PREFIX}'):
            conn.delete(key)
            i += 1
    except redis.exceptions.ResponseError as e:
        new_host = e.args[0].split(' ')[2].split(':')[0]
        print('Redis exception: ' + e.args[0])
        print('New host: ' + new_host)
        conn = redis.Redis(host=new_host, username=REDIS_USER, password=REDIS_PASS, decode_responses=True, ssl=False)
        for key in conn.scan_iter('${REDIS_KEY_PREFIX}'):
            conn.delete(key)
            i += 1
    print('Removed {} keys in Redis'.format(i))
EOF

cat <<EOF | kubectl apply -n ${NAMESPACE_NAME} -f  -
apiVersion: v1
kind: Pod
metadata:
  name: redis-helper
spec:
  containers:
  - name: redis-helper
    image: python:3.8.13-slim-buster
    args:
      ['bash', '-c', 'pip3 install redis && sleep 600']
    volumeMounts:
    - name: redis-cleanup
      mountPath: /etc/redis-cleanup
    resources:
      limits:
        cpu: 500m
        memory: 512Mi
      requests:
        cpu: 100m
        memory: 128Mi
  volumes:
  - name: redis-cleanup
    configMap:
      name: redis-cleanup
EOF

kubectl wait --for=condition=ready pod redis-helper -n ${NAMESPACE_NAME} --timeout 600s
sleep 20
kubectl exec redis-helper -n ${NAMESPACE_NAME} -- bash -c "python3 /etc/redis-cleanup/redis-cleanup.py"
kubectl delete configmap redis-cleanup -n ${NAMESPACE_NAME}
kubectl delete pod redis-helper -n ${NAMESPACE_NAME}
