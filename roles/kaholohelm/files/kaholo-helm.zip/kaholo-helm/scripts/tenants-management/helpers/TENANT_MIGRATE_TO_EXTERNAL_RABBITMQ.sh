#!/bin/bash -
set -e  # Exit immediately if a command exits with a non-zero status
set -o pipefail # Causes a pipeline to return the exit status of the last command in the pipe that returned a non-zero return value

MQ_URL=$1
MQ_USERNAME_ADMIN=$2
MQ_PASSWORD_ADMIN=$3
NAMESPACE_NAME=$4

MQ_PASSWORD_BIGBIRD=$(tr -dc A-Za-z0-9 </dev/urandom | head -c 30 ; echo '')
MQ_PASSWORD_TWIDDLEBUG=$(tr -dc A-Za-z0-9 </dev/urandom | head -c 30 ; echo '')
MQ_PASSWORD_CM=$(tr -dc A-Za-z0-9 </dev/urandom | head -c 30 ; echo '')

curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT ${MQ_URL}/api/vhosts/${NAMESPACE_NAME}_actions
curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT ${MQ_URL}/api/vhosts/${NAMESPACE_NAME}_results
curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT ${MQ_URL}/api/vhosts/${NAMESPACE_NAME}_events

curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT -d'{"password":"'$MQ_PASSWORD_BIGBIRD'","tags":""}' ${MQ_URL}/api/users/${NAMESPACE_NAME}_platform
curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT -d'{"configure":".*","write":"","read":".*"}' ${MQ_URL}/api/permissions/${NAMESPACE_NAME}_results/${NAMESPACE_NAME}_platform
curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT -d'{"configure":".*","write":".*","read":""}' ${MQ_URL}/api/permissions/${NAMESPACE_NAME}_actions/${NAMESPACE_NAME}_platform
curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT -d'{"configure":".*","write":".*","read":".*"}' ${MQ_URL}/api/permissions/${NAMESPACE_NAME}_events/${NAMESPACE_NAME}_platform
curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT -d'{"password":"'$MQ_PASSWORD_TWIDDLEBUG'","tags":""}' ${MQ_URL}/api/users/${NAMESPACE_NAME}_agent
curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT -d'{"configure":".*","write":".*","read":""}' ${MQ_URL}/api/permissions/${NAMESPACE_NAME}_results/${NAMESPACE_NAME}_agent
curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT -d'{"configure":".*","write":"","read":".*"}' ${MQ_URL}/api/permissions/${NAMESPACE_NAME}_actions/${NAMESPACE_NAME}_agent
curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT -d'{"password":"'$MQ_PASSWORD_CM'","tags":""}' ${MQ_URL}/api/users/${NAMESPACE_NAME}_service
curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT -d'{"configure":".*","write":"","read":".*"}' ${MQ_URL}/api/permissions/${NAMESPACE_NAME}_results/${NAMESPACE_NAME}_service
curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT -d'{"configure":".*","write":".*","read":""}' ${MQ_URL}/api/permissions/${NAMESPACE_NAME}_actions/${NAMESPACE_NAME}_service
curl --fail -s -i -u ${MQ_USERNAME_ADMIN}:${MQ_PASSWORD_ADMIN} -H "content-type:application/json" -XPUT -d'{"configure":".*","write":".*","read":".*"}' ${MQ_URL}/api/permissions/${NAMESPACE_NAME}_events/${NAMESPACE_NAME}_service

kubectl get secret platform-env-secret -n $NAMESPACE_NAME -o jsonpath="{.data.config}" | base64 -d > config
cp config config-platform-${NAMESPACE_NAME}
kubectl create secret generic platform-env-secret-old --from-file config -n $NAMESPACE_NAME
sed -iE "s/amqp.*rabbitmq:5672\//amqp:\/\/${NAMESPACE_NAME}_platform:${MQ_PASSWORD_BIGBIRD}@rabbitmq.rabbitmq:5672\/${NAMESPACE_NAME}_/g" config
kubectl delete secret platform-env-secret -n $NAMESPACE_NAME
kubectl create secret generic platform-env-secret --from-file config -n $NAMESPACE_NAME

kubectl get secret service-env-secret -n $NAMESPACE_NAME -o jsonpath="{.data.config}" | base64 -d > config
kubectl create secret generic service-env-secret-old --from-file config -n $NAMESPACE_NAME
cp config config-service-${NAMESPACE_NAME}
sed -iE "s/amqp.*rabbitmq:5672\//amqp:\/\/${NAMESPACE_NAME}_service:${MQ_PASSWORD_CM}@rabbitmq.rabbitmq:5672\/${NAMESPACE_NAME}_/g" config
kubectl delete secret service-env-secret -n $NAMESPACE_NAME
kubectl create secret generic service-env-secret --from-file config -n $NAMESPACE_NAME

kubectl get secret agent-env-secret -n $NAMESPACE_NAME -o jsonpath="{.data.config}" | base64 -d > config
kubectl create secret generic agent-env-secret-old --from-file config -n $NAMESPACE_NAME
cp config config-agent-${NAMESPACE_NAME}
sed -iE "s/amqp.*rabbitmq:5672\//amqp:\/\/${NAMESPACE_NAME}_agent:${MQ_PASSWORD_TWIDDLEBUG}@rabbitmq.rabbitmq:5672\/${NAMESPACE_NAME}_/g" config
kubectl delete secret agent-env-secret -n $NAMESPACE_NAME
kubectl create secret generic agent-env-secret --from-file config -n $NAMESPACE_NAME

cd ../../../
helm get values $NAMESPACE_NAME -n $NAMESPACE_NAME > values-$NAMESPACE_NAME.yaml
cp values-$NAMESPACE_NAME.yaml values-$NAMESPACE_NAME.yaml_original
sed -i 's/networkPolicy:/networkPolicy:\n  allowAgentTrafficToK8SRabbitMQ: true/g' values-$NAMESPACE_NAME.yaml 
sed -i 's/^rabbitmq:/rabbitmq:\n  enabled: false/g' values-$NAMESPACE_NAME.yaml 
! diff values-$NAMESPACE_NAME.yaml values-$NAMESPACE_NAME.yaml_original
# helm diff upgrade $NAMESPACE_NAME . -n $NAMESPACE_NAME -f values-$NAMESPACE_NAME.yaml
# exit 1
helm upgrade $NAMESPACE_NAME . -n $NAMESPACE_NAME -f values-$NAMESPACE_NAME.yaml

kubectl rollout restart deployment -n $NAMESPACE_NAME

kubectl get deploy --no-headers=true -n $NAMESPACE_NAME | awk '$1 {print$1}' | while read vol; do kubectl rollout status deployment $vol --timeout=300s -n $NAMESPACE_NAME; done
