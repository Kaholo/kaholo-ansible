#!/bin/bash -
set -e  # Exit immediately if a command exits with a non-zero status
set -o pipefail # Causes a pipeline to return the exit status of the last command in the pipe that returned a non-zero return value

NAMESPACE_NAME=$1
MONGO_URI=$2
MONGO_HOST_PORT=$3

MONGODB_KAHOLO_DB_USERNAME=$NAMESPACE_NAME
MONGODB_KAHOLO_DB_PASSWORD=$(tr -dc A-Za-z0-9 </dev/urandom | head -c 30 ; echo '')
./TENANT_INIT_MONGODB.sh ${MONGO_URI} ${MONGODB_KAHOLO_DB_USERNAME} ${NAMESPACE_NAME} ${MONGODB_KAHOLO_DB_PASSWORD}

MONGO_URI="mongodb://${MONGODB_KAHOLO_DB_USERNAME}:${MONGODB_KAHOLO_DB_PASSWORD}@${MONGO_HOST_PORT}"
MONGO_URI_ESCAPED="${MONGO_URI//\//\\\/}"

cd ../
mkdir -p $NAMESPACE_NAME && ./TENANT_DUMP.sh -n ${NAMESPACE_NAME} -p $NAMESPACE_NAME/ -d kaholo -m

kubectl get secret platform-env-secret -n $NAMESPACE_NAME -o jsonpath="{.data.config}" | base64 -d > config
cp config config-platform-${NAMESPACE_NAME}
kubectl delete secret platform-env-secret-old -n $NAMESPACE_NAME || true
kubectl create secret generic platform-env-secret-old --from-file config -n $NAMESPACE_NAME
sed -iE "s/DB_URI='.*'/DB_URI='${MONGO_URI_ESCAPED}'/g" config
kubectl delete secret platform-env-secret -n $NAMESPACE_NAME
kubectl create secret generic platform-env-secret --from-file config -n $NAMESPACE_NAME

kubectl get secret service-env-secret -n $NAMESPACE_NAME -o jsonpath="{.data.config}" | base64 -d > config
cp config config-service-${NAMESPACE_NAME}
kubectl delete secret service-env-secret-old -n $NAMESPACE_NAME || true
kubectl create secret generic service-env-secret-old --from-file config -n $NAMESPACE_NAME
cp config config-service-${NAMESPACE_NAME}
sed -iE "s/DB_URI='.*'/DB_URI='${MONGO_URI_ESCAPED}'/g" config
kubectl delete secret service-env-secret -n $NAMESPACE_NAME
kubectl create secret generic service-env-secret --from-file config -n $NAMESPACE_NAME

./TENANT_RESTORE.sh -n ${NAMESPACE_NAME} -p ${NAMESPACE_NAME}/ -d $NAMESPACE_NAME -s kaholo -m

cd ../../
helm get values $NAMESPACE_NAME -n $NAMESPACE_NAME > values-$NAMESPACE_NAME.yaml
cp values-$NAMESPACE_NAME.yaml values-$NAMESPACE_NAME.yaml_original
sed -i "s/^global:/global:\n  tenantId: $NAMESPACE_NAME/g" values-$NAMESPACE_NAME.yaml 
sed -i 's/^mongodb:/mongodb:\n  enabled: false/g' values-$NAMESPACE_NAME.yaml 
! diff values-$NAMESPACE_NAME.yaml values-$NAMESPACE_NAME.yaml_original
# helm diff upgrade $NAMESPACE_NAME . -n $NAMESPACE_NAME -f values-$NAMESPACE_NAME.yaml
# exit 1
helm upgrade $NAMESPACE_NAME . -n $NAMESPACE_NAME -f values-$NAMESPACE_NAME.yaml

kubectl rollout restart deployment -n $NAMESPACE_NAME

kubectl get deploy --no-headers=true -n $NAMESPACE_NAME | awk '$1 {print$1}' | while read vol; do kubectl rollout status deployment $vol --timeout=300s -n $NAMESPACE_NAME; done
