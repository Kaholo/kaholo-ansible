#!/bin/bash -
set -e  # Exit immediately if a command exits with a non-zero status
set -o pipefail # Causes a pipeline to return the exit status of the last command in the pipe that returned a non-zero return value

MONGO_URI=$1
MONGO_DB_NAME=$2
MONGO_DB_USERNAME=$3
MONGO_DB_PASSWORD=$4

NAMESPACE_NAME=$MONGO_DB_NAME


create_migration_helper_pod() {
    cat <<EOF | kubectl apply -n ${NAMESPACE_NAME} -f  -
apiVersion: v1
kind: Pod
metadata:
  name: kaholo-migration-helper
spec:
  containers:
  - name: kaholo-migration-helper
    image: mongo:4.4.20
    command: ["/bin/sh", "-c"]
    args:
    - "sleep 3600"
    resources:
      limits:
        cpu: 200m
        memory: 512Mi
      requests:
        cpu: 10m
        memory: 50Mi
EOF
    kubectl wait --for=condition=ready pod kaholo-migration-helper -n ${NAMESPACE_NAME} --timeout 600s
}

create_migration_helper_pod

kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- \
    bash -c "mongo '${MONGO_URI}' --eval 'db.getSiblingDB(\"${MONGO_DB_NAME}\").createUser({ user : \"${MONGO_DB_USERNAME}\", pwd :  \"${MONGO_DB_PASSWORD}\", roles : [{ role: \"readWrite\", db: \"${MONGO_DB_NAME}\"}], passwordDigestor: \"server\"});'"

kubectl delete pod kaholo-migration-helper -n ${NAMESPACE_NAME}
