#!/bin/bash
set -e  # Exit immediately if a command exits with a non-zero status
set -o pipefail # Causes a pipeline to return the exit status of the last command in the pipe that returned a non-zero return value
HOME_DIR=$(pwd)

NAMESPACE_NAME=$1
DUMPS_DIR=$2

kubectl apply -f ../migration/migration-helper-pod.yaml -n ${NAMESPACE_NAME}
kubectl wait --for=condition=ready pod kaholo-migration-helper -n ${NAMESPACE_NAME} --timeout 600s

kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- bash -c "source /vault/secrets/config && mongodump --uri=\"\${DB_URI}\" --gzip --archive=/dump5.gz --forceTableScan"

kubectl cp --retries=10 --no-preserve=true -n ${NAMESPACE_NAME} kaholo-migration-helper:/dump5.gz ${DUMPS_DIR}/dump.gz
kubectl cp --retries=10 --no-preserve=true -n ${NAMESPACE_NAME} kaholo-migration-helper:/storage ${DUMPS_DIR}/storage
kubectl cp --retries=10 --no-preserve=true -n ${NAMESPACE_NAME} kaholo-migration-helper:/bigbird/server/libs/plugins ${DUMPS_DIR}/plugins
kubectl cp --retries=10 --no-preserve=true -n ${NAMESPACE_NAME} kaholo-migration-helper:/bigbird/static_cdn/uploads ${DUMPS_DIR}/uploads

kubectl delete -f ../migration/migration-helper-pod.yaml -n ${NAMESPACE_NAME}
