#!/bin/bash
set -e  # Exit immediately if a command exits with a non-zero status
set -o pipefail # Causes a pipeline to return the exit status of the last command in the pipe that returned a non-zero return value
HOME_DIR=$(pwd)

PROGNAME=$0

usage() {
  cat << EOF >&2
Usage: $PROGNAME

 -n    <NAMESPACE_NAME>:    Name of Kaholo Helm Release and Kubernetes Namespace (required)
 -p    <DUMPS_DIR>:         Directory where dumps data will be placed
 -d    <DB_NAME>:           Database name
 -m    <DB_ONLY>:           Dump only MongoDB database data
 -v    <VAULT>:             Use Vault secrets

EOF
  exit 1
}

DB_ONLY="false"
DB_NAME="kaholo"
VAULT="false"
while getopts n:p:d:mv opt; do
  case $opt in
    (n) NAMESPACE_NAME=$OPTARG;;
    (p) DUMPS_DIR=$OPTARG;;
    (d) DB_NAME=$OPTARG;;
    (m) DB_ONLY=true;;
    (v) VAULT=true;;
    (*) usage
  esac
done
shift "$((OPTIND - 1))"

echo Remaining arguments: "$@"


create_migration_helper_pod() {
    tee -a helper-pod.yaml > /dev/null <<EOT
apiVersion: v1
kind: Pod
metadata:
  name: kaholo-migration-helper
spec:
  containers:
  - name: kaholo-migration-helper
    image: mongo:4.4.20
    command: ["/bin/sh", "-c"]
    args:
    - "sleep 3600"
EOT
    if [ "$VAULT" = true ]; then
    tee -a helper-pod.yaml > /dev/null <<EOT
    env:
    - name: MONGODB_USERNAME
      valueFrom:
        secretKeyRef:
          name: "mongodb-creds"
          key: username
    - name: MONGODB_PASSWORD
      valueFrom:
        secretKeyRef:
          name: "mongodb-creds"
          key: password
EOT
    fi
    tee -a helper-pod.yaml > /dev/null <<EOT
    volumeMounts:
    - name: plugins-persistent-storage
      mountPath: /bigbird/server/libs/plugins
    - mountPath: /bigbird/static_cdn/uploads
      name: pluginscdn-persistent-storage
    - mountPath: /static_cdn/uploads
      name: pluginscdn-persistent-storage
    - mountPath: /storage
      name: storage-persistent-storage
    - name: env-secret
      mountPath: /vault/secrets
      readOnly: true
    resources:
      limits:
        cpu: 2000m
        memory: 4096Mi
      requests:
        cpu: 500m
        memory: 512Mi
  volumes:
  - name: plugins-persistent-storage
    persistentVolumeClaim:
      claimName: platform-plugins-claim
  - name: pluginscdn-persistent-storage
    persistentVolumeClaim:
      claimName: platform-pluginscdn-claim
  - name: storage-persistent-storage
    persistentVolumeClaim:
      claimName: platform-storage-claim
  - name: env-secret
    secret:
      secretName: platform-env-secret
EOT
    kubectl apply -f helper-pod.yaml -n ${NAMESPACE_NAME}
    rm helper-pod.yaml
    kubectl wait --for=condition=ready pod kaholo-migration-helper -n ${NAMESPACE_NAME} --timeout 600s
}

create_migration_helper_pod

kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- bash -c "source /vault/secrets/config && mongodump --uri=\"\${DB_URI}/${DB_NAME}\" --gzip --archive=/dump5.gz --forceTableScan"

kubectl cp --retries=10 --no-preserve=true -n ${NAMESPACE_NAME} kaholo-migration-helper:/dump5.gz ${DUMPS_DIR}/dump.gz
if ! [ "$DB_ONLY" = true ]; then
    kubectl cp --retries=10 --no-preserve=true -n ${NAMESPACE_NAME} kaholo-migration-helper:/storage ${DUMPS_DIR}/storage
    kubectl cp --retries=10 --no-preserve=true -n ${NAMESPACE_NAME} kaholo-migration-helper:/bigbird/server/libs/plugins ${DUMPS_DIR}/plugins
    kubectl cp --retries=10 --no-preserve=true -n ${NAMESPACE_NAME} kaholo-migration-helper:/bigbird/static_cdn/uploads ${DUMPS_DIR}/uploads
fi

kubectl delete pod kaholo-migration-helper -n ${NAMESPACE_NAME}
