#!/bin/bash
set -e  # Exit immediately if a command exits with a non-zero status
set -o pipefail # Causes a pipeline to return the exit status of the last command in the pipe that returned a non-zero return value
HOME_DIR=$(pwd)

NAMESPACE_NAME=$1
SOURCE_DB_NAME=$2
DUMPS_DIR=$3


scale_up() {
    kubectl scale deployment -l platform=kaholo --replicas 1 -n ${NAMESPACE_NAME}
    kubectl scale statefulset -l platform=kaholo --replicas 1 -n ${NAMESPACE_NAME}
}

scale_down() {
    kubectl scale deployment -l platform=kaholo --replicas 0 -n ${NAMESPACE_NAME}
    kubectl scale statefulset -l platform=kaholo --replicas 0 -n ${NAMESPACE_NAME}
    kubectl wait pod -l platform=kaholo --for=delete -n ${NAMESPACE_NAME} --timeout 600s
}


kubectl apply -f ../migration/migration-helper-pod.yaml -n ${NAMESPACE_NAME}

scale_down

kubectl wait --for=condition=ready pod kaholo-migration-helper -n ${NAMESPACE_NAME} --timeout 600s

kubectl cp --no-preserve=true -n ${NAMESPACE_NAME} ${DUMPS_DIR}plugins kaholo-migration-helper:/bigbird/server/libs
kubectl cp --no-preserve=true -n ${NAMESPACE_NAME} ${DUMPS_DIR}uploads kaholo-migration-helper:/bigbird/static_cdn
kubectl cp --no-preserve=true -n ${NAMESPACE_NAME} ${DUMPS_DIR}storage kaholo-migration-helper:/
kubectl cp --no-preserve=true -n ${NAMESPACE_NAME} ${DUMPS_DIR}dump.gz kaholo-migration-helper:/

kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- bash -c "source /vault/secrets/config && mongorestore --uri=\"\${DB_URI}/kaholo\" --drop --gzip --archive=/dump.gz --nsInclude '${SOURCE_DB_NAME}.*' --nsFrom '${SOURCE_DB_NAME}.*' --nsTo 'kaholo.*'"

scale_up

kubectl delete -f ../migration/migration-helper-pod.yaml -n ${NAMESPACE_NAME}
