#!/bin/bash
set -e  # Exit immediately if a command exits with a non-zero status
set -o pipefail # Causes a pipeline to return the exit status of the last command in the pipe that returned a non-zero return value
HOME_DIR=$(pwd)

PROGNAME=$0

usage() {
  cat << EOF >&2
Usage: $PROGNAME

 -n    <NAMESPACE_NAME>:    Name of Kaholo Helm Release and Kubernetes Namespace (required)
 -m    <MONGO_DUMP_FILE>:   Name of mongo dump file (start with gs://file_address to restore from GCS bucket)
 -p    <PLUGINS_DUMP_FILE>: Name of plugins dump file (start with gs://file_address to restore from GCS bucket)
 -u    <UPLOADS_DUMP_FILE>: Name of uploads dump file (start with gs://file_address to restore from GCS bucket)
 -s    <STORAGE_DUMP_FILE>: Name of storage dump file (start with gs://file_address to restore from GCS bucket)
 -f    <GCP_SA_KEY_PATH>:   Path to JSON file with GCP Service Account Key for GCS bucket access
 -r    <REDIS_KEY_PREFIX>:  Redis key prefix to clean up
 -l    <LIST_ONLY>:         List available dump files on Kubernetes volumes and exit

EOF
  exit 1
}

# verbose_level=0
LIST_ONLY="false"
while getopts n:m:p:u:s:f:r:l opt; do
  case $opt in
    (n) NAMESPACE_NAME=$OPTARG;;
    (m) MONGO_DUMP_FILE=$OPTARG;;
    (p) PLUGINS_DUMP_FILE=$OPTARG;;
    (u) UPLOADS_DUMP_FILE=$OPTARG;;
    (s) STORAGE_DUMP_FILE=$OPTARG;;
    (f) GCP_SA_KEY_PATH=$OPTARG;;
    (r) REDIS_KEY_PREFIX=$OPTARG;;
    (l) LIST_ONLY=true;;
    (*) usage
  esac
done
shift "$((OPTIND - 1))"

echo Remaining arguments: "$@"

if [ -z "$NAMESPACE_NAME" ]; then
  printf "\nTenant name is required\n\n"
  usage
fi

create_migration_helper_pod() {
    cat <<EOF | kubectl apply -n ${NAMESPACE_NAME} -f  -
apiVersion: v1
kind: Pod
metadata:
  name: kaholo-migration-helper
spec:
  containers:
  - name: kaholo-migration-helper
    image: mongo:4.4.20
    command: ["/bin/sh", "-c"]
    args:
    - "sleep 3600"
    volumeMounts:
    - name: plugins-persistent-storage
      mountPath: /bigbird/server/libs/plugins
    - mountPath: /bigbird/static_cdn/uploads
      name: pluginscdn-persistent-storage
    - mountPath: /static_cdn/uploads
      name: pluginscdn-persistent-storage
    - mountPath: /storage
      name: storage-persistent-storage
    - name: mongo-dump-storage
      mountPath: "/mongo-dump"
    - name: plugins-dump-storage
      mountPath: "/plugins-dump"
    - name: storage-dump-storage
      mountPath: "/storage-dump"
    - name: env-secret
      mountPath: /vault/secrets
      readOnly: true
    resources:
      limits:
        cpu: 2000m
        memory: 4096Mi
      requests:
        cpu: 500m
        memory: 512Mi
  volumes:
  - name: plugins-persistent-storage
    persistentVolumeClaim:
      claimName: platform-plugins-claim
  - name: pluginscdn-persistent-storage
    persistentVolumeClaim:
      claimName: platform-pluginscdn-claim
  - name: storage-persistent-storage
    persistentVolumeClaim:
      claimName: platform-storage-claim
  - name: storage-dump-storage
    persistentVolumeClaim:
      claimName: storage-dump-pvc
  - name: mongo-dump-storage
    persistentVolumeClaim:
      claimName: mongo-dump-pvc
  - name: plugins-dump-storage
    persistentVolumeClaim:
      claimName: plugins-dump-pvc
  - name: env-secret
    secret:
      secretName: platform-env-secret
EOF
    kubectl wait --for=condition=ready pod kaholo-migration-helper -n ${NAMESPACE_NAME} --timeout 600s
}

scale_up() {
    kubectl scale deployment -l platform=kaholo --replicas 1 -n ${NAMESPACE_NAME}
    kubectl scale statefulset -l platform=kaholo --replicas 1 -n ${NAMESPACE_NAME}
}

scale_down() {
    kubectl scale deployment -l platform=kaholo --replicas 0 -n ${NAMESPACE_NAME}
    kubectl scale statefulset -l platform=kaholo --replicas 0 -n ${NAMESPACE_NAME}
    kubectl wait pod -l platform=kaholo --for=delete -n ${NAMESPACE_NAME} --timeout 600s
}

redis_cleanup() {
    cat <<EOF | kubectl apply -n ${NAMESPACE_NAME} -f  -
apiVersion: v1
kind: ConfigMap
metadata:
  name: redis-cleanup
data:
  redis-cleanup.py: |
    import redis
    import os
    i=0
    conn = redis.from_url(os.environ['REDIS_URL'])
    try:
        print('Removing keys with prefix ${REDIS_KEY_PREFIX}')
        for key in conn.scan_iter('${REDIS_KEY_PREFIX}'):
            conn.delete(key)
            i += 1
    except redis.exceptions.ResponseError as e:
        new_host = e.args[0].split(' ')[2].split(':')[0]
        print('Redis exception: ' + e.args[0])
        print('New host: ' + new_host)
        conn = redis.Redis(host=new_host, username=REDIS_USER, password=REDIS_PASS, decode_responses=True, ssl=False)
        for key in conn.scan_iter('${REDIS_KEY_PREFIX}'):
            conn.delete(key)
            i += 1
    print('Removed {} keys in Redis'.format(i))
EOF
    cat <<EOF | kubectl apply -n ${NAMESPACE_NAME} -f  -
apiVersion: v1
kind: Pod
metadata:
  name: redis-helper
spec:
  containers:
  - name: redis-helper
    image: python:3.8.13-slim-buster
    args:
      ['bash', '-c', 'pip3 install redis && sleep 600']
    volumeMounts:
    - name: env-secret
      mountPath: /vault/secrets
      readOnly: true
    - name: redis-cleanup
      mountPath: /etc/redis-cleanup
    resources:
      limits:
        cpu: 500m
        memory: 512Mi
      requests:
        cpu: 100m
        memory: 128Mi
  volumes:
  - name: env-secret
    secret:
      secretName: platform-env-secret
  - name: redis-cleanup
    configMap:
      name: redis-cleanup
EOF
  kubectl wait --for=condition=ready pod redis-helper -n ${NAMESPACE_NAME} --timeout 600s
  sleep 20
  kubectl exec redis-helper -n ${NAMESPACE_NAME} -- bash -c "source /vault/secrets/config && python3 /etc/redis-cleanup/redis-cleanup.py"
  kubectl delete configmap redis-cleanup -n ${NAMESPACE_NAME}
  kubectl delete pod redis-helper -n ${NAMESPACE_NAME}
}
##########################################################################################

mongo_restore () {
  ! [ -z "$MONGO_DUMP_FILE" ]
}
plugins_restore () {
  ! [ -z "$PLUGINS_DUMP_FILE" ]
}
uploads_restore () {
  ! [ -z "$UPLOADS_DUMP_FILE" ]
}
storage_restore () {
  ! [ -z "$STORAGE_DUMP_FILE" ]
}
mongo_restore_from_gcs() {
  [[ "$MONGO_DUMP_FILE" == gs://* ]]
}
plugins_restore_from_gcs() {
  [[ "$PLUGINS_DUMP_FILE" == gs://* ]]
}
uploads_restore_from_gcs() {
  [[ "$UPLOADS_DUMP_FILE" == gs://* ]]
}
storage_restore_from_gcs() {
  [[ "$STORAGE_DUMP_FILE" == gs://* ]]
}

if mongo_restore_from_gcs || plugins_restore_from_gcs || uploads_restore_from_gcs || storage_restore_from_gcs; then
  if [ -z "$GCP_SA_KEY_PATH" ]; then
    printf "\nGCP service account key path is required for GCS dumps. Exiting.\n\n"
    exit 2
  fi
fi

if mongo_restore; then
  if [ -z "$REDIS_KEY_PREFIX" ]; then
    printf "\nRedis key prefix is required\n\n"
    usage
  fi
fi

create_migration_helper_pod

if [ "$LIST_ONLY" = true ]; then
  printf "\n-\nMongo dumps available:\n-\n"
  kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- \
    bash -c "cd /mongo-dump && ls -t"

  printf "\n-\nPlugins dumps available:\n-\n"
  kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- \
    bash -c "cd /plugins-dump/plugins && ls -t"

  printf "\n-\nUploads dumps available:\n-\n"
  kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- \
    bash -c "cd /plugins-dump/uploads && ls -t"

  printf "\n-\nStorage dumps available:\n-\n"
  kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- \
    bash -c "cd /storage-dump && ls -t"

  printf "\nSelecting -l option will list the available dumps and exit.\n"
  exit 0
fi

if ! mongo_restore && ! plugins_restore && ! storage_restore; then
  printf "\nNo dump files provided. Rememeber, if you want to restore plugins you need to provide plugins dump file and uploads dump file!\nExiting.\n\n"
  exit 2
fi

if mongo_restore_from_gcs || plugins_restore_from_gcs || storage_restore_from_gcs; then
  printf "\nPreparing GCP service account key and gcloud for migration helper pod\n\n"
  kubectl cp ${GCP_SA_KEY_PATH} kaholo-migration-helper:/tmp/key.json -n ${NAMESPACE_NAME}
  kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- \
    bash -c "apt-get update -y && apt-get install -y curl python3 &&
              rm -rf ~/gcloud && curl -sSL https://sdk.cloud.google.com > /tmp/gcl && bash /tmp/gcl --install-dir=~/gcloud --disable-prompts;
              ~/gcloud/google-cloud-sdk/bin/gcloud auth activate-service-account --key-file /tmp/key.json"
fi

if mongo_restore; then
  printf "\nRestoring Mongo from ${MONGO_DUMP_FILE}\n\n"
  scale_down
  redis_cleanup
fi

if mongo_restore; then
  if mongo_restore_from_gcs; then
    printf "\nRestoring mongo dump ${MONGO_DUMP_FILE} from GCS\n\n"
    kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- \
      bash -c "mkdir -p /tmp/mongo-dump && ~/gcloud/google-cloud-sdk/bin/gcloud storage cp ${MONGO_DUMP_FILE} /tmp/mongo-dump/dump.tar.gz"
    kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- \
      bash -c "source /vault/secrets/config && mongorestore --uri=\${DB_URI%\?*}/kaholo --drop --gzip --archive=/tmp/mongo-dump/dump.tar.gz"
  else
    printf "\nRestoring mongo dump ${MONGO_DUMP_FILE} from Persistant Volume\n\n"
    kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- \
      bash -c "source /vault/secrets/config && mongorestore --uri=\${DB_URI%\?*}/kaholo --drop --gzip --archive=/mongo-dump/${MONGO_DUMP_FILE}"
  fi
fi

if plugins_restore; then
  if plugins_restore_from_gcs; then
    printf "\nRestoring plugins dump ${PLUGINS_DUMP_FILE} from GCS \n\n"
    kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- \
      bash -c "mkdir -p /tmo/plugins && ~/gcloud/google-cloud-sdk/bin/gcloud storage cp ${PLUGINS_DUMP_FILE} /tmp/plugins/dump.tar.gz"
    kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- \
      bash -c "rm -rf /bigbird/server/libs/plugins/* && tar -xzf /tmp/plugins/dump.tar.gz -C /bigbird/server/libs/plugins"
  else
    printf "\nRestoring plugins dump ${PLUGINS_DUMP_FILE} from Persistant Volume\n\n"
    kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- \
      bash -c "rm -rf /bigbird/server/libs/plugins/* && tar -xzf /plugins-dump/plugins/${PLUGINS_DUMP_FILE} -C /bigbird/server/libs/plugins"
  fi
fi

if uploads_restore; then
  if uploads_restore_from_gcs; then
    printf "\nRestoring uploads dump ${UPLOADS_DUMP_FILE} from GCS \n\n"
    kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- \
      bash -c "mkdir -p /tmp/uploads && ~/gcloud/google-cloud-sdk/bin/gcloud storage cp ${UPLOADS_DUMP_FILE} /tmp/uploads/dump.tar.gz"
    kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- \
      bash -c "rm -rf /bigbird/static_cdn/uploads/* && tar -xzf /tmp/uploads/dump.tar.gz -C /bigbird/static_cdn/uploads"
  else
    printf "\nRestoring uploads dump ${UPLOADS_DUMP_FILE} from Persistant Volume\n\n"
    kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- \
      bash -c "rm -rf /bigbird/static_cdn/uploads/* && tar -xzf /plugins-dump/uploads/${UPLOADS_DUMP_FILE} -C /bigbird/static_cdn/uploads"
  fi
fi

if storage_restore; then
  if storage_restore_from_gcs; then
    printf "\nRestoring storage dump ${STORAGE_DUMP_FILE} from GCS\n\n"
    kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- \
      bash -c "mkdir -p /tmp/storage-dump && ~/gcloud/google-cloud-sdk/bin/gcloud storage cp ${STORAGE_DUMP_FILE} /tmp/storage-dump/dump.tar.gz"
    kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- \
      bash -c "tar --keep-newer-files -xzf /tmp/storage-dump/dump.tar.gz -C /storage" | tail -30
  else
    printf "\nRestoring storage dump ${STORAGE_DUMP_FILE} from Persistant Volume\n\n"
    kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- \
      bash -c "tar --keep-newer-files -xzf /storage-dump/${STORAGE_DUMP_FILE} -C /storage" | tail -30
  fi
fi

if mongo_restore; then
  scale_up
fi

kubectl delete pod kaholo-migration-helper -n ${NAMESPACE_NAME}

exit 0

##########################################################################################






check_mongo_env() {
    if [ -z "${MONGO_DUMP_FILE}" ]
    then
       echo "You need to pass MONGO_DUMP_FILE explicitly!"
       exit 1
    fi
}

check_plugins_env() {
    if [ -z "${PLUGINS_DUMP_FILE}" ]
    then
       echo "You need to pass PLUGINS_DUMP_FILE explicitly!"
       exit 1
    fi
}

check_storage_env() {
    if [ -z "${STORAGE_DUMP_FILE}" ]
    then
       echo "You need to pass STORAGE_DUMP_FILE explicitly!"
       exit 1
    fi
}

if [[ "$MODE" == "restore-all" ]]
then

    check_mongo_env
    check_plugins_env
    check_storage_env
    create_migration_helper_pod
    scale_down
    redis_cleanup
    kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- \
      bash -c "source /vault/secrets/config && mongorestore --uri=\${DB_URI%\?*}/kaholo --drop --gzip --archive=/mongo-dump/${MONGO_DUMP_FILE}"
    kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- \
      bash -c "rm -rf /bigbird/server/libs/plugins/* && tar -xzf /plugins-dump/plugins/${PLUGINS_DUMP_FILE} -C /bigbird/server/libs/plugins"
    kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- \
      bash -c "rm -rf /bigbird/static_cdn/uploads/* && tar -xzf /plugins-dump/uploads/${PLUGINS_DUMP_FILE} -C /bigbird/static_cdn/uploads"
    kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- \
      bash -c "tar -xzf /storage-dump/${STORAGE_DUMP_FILE} -C /storage"
    scale_up

elif [[ "$MODE" == "restore-mongo" ]]
then

    check_mongo_env
    create_migration_helper_pod
    scale_down
    redis_cleanup
    kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- \
      bash -c "source /vault/secrets/config && mongorestore --uri=\${DB_URI%\?*}/kaholo --drop --gzip --archive=/mongo-dump/${MONGO_DUMP_FILE}"
    scale_up

elif [[ "$MODE" == "restore-plugins" ]]
then

    check_plugins_env
    create_migration_helper_pod
    scale_down
    kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- \
      bash -c "rm -rf /bigbird/server/libs/plugins/* && tar -xzf /plugins-dump/plugins/${PLUGINS_DUMP_FILE} -C /bigbird/server/libs/plugins"
    kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- \
      bash -c "rm -rf /bigbird/static_cdn/uploads/* && tar -xzf /plugins-dump/uploads/${PLUGINS_DUMP_FILE} -C /bigbird/static_cdn/uploads"

elif [[ "$MODE" == "restore-storage" ]]
then

    check_storage_env
    create_migration_helper_pod
    kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- \
      bash -c "tar -xzf /storage-dump/${STORAGE_DUMP_FILE} -C /storage"

else

    create_migration_helper_pod
    printf "\n-\nMongo dumps available:\n-\n"
    kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- \
      bash -c "cd /mongo-dump && ls -t"

    printf "\n-\nPlugins dumps available:\n-\n"
    kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- \
      bash -c "cd /plugins-dump/plugins && ls -t"

    printf "\n-\nStorage dumps available:\n-\n"
    kubectl exec --stdin --tty -n ${NAMESPACE_NAME} kaholo-migration-helper -- \
      bash -c "cd /storage-dump && ls -t"

fi

kubectl delete pod kaholo-migration-helper -n ${NAMESPACE_NAME}
