#!/bin/bash
set -e  # Exit immediately if a command exits with a non-zero status
set -o pipefail # Causes a pipeline to return the exit status of the last command in the pipe that returned a non-zero return value
HOME_DIR=$(pwd)

# ./TENANT_RESTORE.sh k8sonly restore-all dump_20221221T0925.gz plugins_20221221T0925.tgz

TENANT_NAME=$1
MODE=$2 # list-dumps / restore-all / restore-mongo / restore-plugins
MONGO_DUMP_FILENAME=$3
PLUGINS_DUMP_FILENAME=$4

create_migration_helper_pod() {
    cat <<EOF | kubectl apply -n kaholo-${TENANT_NAME} -f  -
apiVersion: v1
kind: Pod
metadata:
  name: kaholo-migration-helper
spec:
  containers:
  - name: kaholo-migration-helper
    image: mongo:4.4.17-rc0
    command: ["/bin/sh", "-c"]
    args:
    - "sleep 3600"
    volumeMounts:
    - name: plugins-persistent-storage
      mountPath: /bigbird/server/libs/plugins
    - mountPath: /bigbird/static_cdn/uploads
      name: pluginscdn-persistent-storage
    - mountPath: /static_cdn/uploads
      name: pluginscdn-persistent-storage
    - name: mongo-dump-storage
      mountPath: "/mongo-dump"
    - name: plugins-dump-storage
      mountPath: "/plugins-dump"
    - name: env-secret
      mountPath: /vault/secrets
      readOnly: true
    resources:
      limits:
        cpu: 500m
        memory: 512Mi
      requests:
        cpu: 10m
        memory: 32Mi
  volumes:
  - name: plugins-persistent-storage
    persistentVolumeClaim:
      claimName: platform-plugins-claim
  - name: pluginscdn-persistent-storage
    persistentVolumeClaim:
      claimName: platform-pluginscdn-claim
  - name: mongo-dump-storage
    persistentVolumeClaim:
      claimName: mongo-dump-pvc
  - name: plugins-dump-storage
    persistentVolumeClaim:
      claimName: plugins-dump-pvc
  - name: env-secret
    secret:
      secretName: platform-env-secret
EOF
    kubectl wait --for=condition=ready pod kaholo-migration-helper -n kaholo-${TENANT_NAME} --timeout 600s
}

scale_up() {
    kubectl scale deployment -l platform=kaholo --replicas 1 -n kaholo-${TENANT_NAME}
    kubectl scale statefulset -l platform=kaholo --replicas 1 -n kaholo-${TENANT_NAME}
    kubectl wait pod -l platform=kaholo --for=condition=ready -n kaholo-${TENANT_NAME} --timeout 600s
}

scale_down() {
    kubectl scale deployment -l platform=kaholo --replicas 0 -n kaholo-${TENANT_NAME}
    kubectl scale statefulset -l platform=kaholo --replicas 0 -n kaholo-${TENANT_NAME}
    kubectl wait pod -l platform=kaholo --for=delete -n kaholo-${TENANT_NAME} --timeout 600s
}

redis_cleanup() {
    cat <<EOF | kubectl apply -n kaholo-${TENANT_NAME} -f  -
apiVersion: v1
kind: ConfigMap
metadata:
  name: redis-cleanup
data:
  redis-cleanup.py: |
    import redis
    import os
    i=0
    conn = redis.from_url(os.environ['REDIS_URL'])
    try:
        print('Removing keys with prefix ${TENANT_NAME}:*')
        for key in conn.scan_iter('${TENANT_NAME}:*'):
            conn.delete(key)
            i += 1
    except redis.exceptions.ResponseError as e:
        new_host = e.args[0].split(' ')[2].split(':')[0]
        print('Redis exception: ' + e.args[0])
        print('New host: ' + new_host)
        conn = redis.Redis(host=new_host, username=REDIS_USER, password=REDIS_PASS, decode_responses=True, ssl=False)
        for key in conn.scan_iter('${TENANT_NAME}'+':*'):
            conn.delete(key)
            i += 1
    print('Removed {} keys in Redis'.format(i))
EOF
    cat <<EOF | kubectl apply -n kaholo-${TENANT_NAME} -f  -
apiVersion: v1
kind: Pod
metadata:
  name: redis-helper
spec:
  containers:
  - name: redis-helper
    image: python:3.8.13-slim-buster
    args:
      ['bash', '-c', 'pip3 install redis && sleep 600']
    volumeMounts:
    - name: env-secret
      mountPath: /vault/secrets
      readOnly: true
    - name: redis-cleanup
      mountPath: /etc/redis-cleanup
    resources:
      limits:
        cpu: 500m
        memory: 512Mi
      requests:
        cpu: 10m
        memory: 32Mi
  volumes:
  - name: env-secret
    secret:
      secretName: platform-env-secret
    volumeMounts:
  - name: redis-cleanup
    configMap:
      name: redis-cleanup
EOF
  kubectl wait --for=condition=ready pod redis-helper -n kaholo-${TENANT_NAME} --timeout 600s
  sleep 10
  kubectl exec redis-helper -n kaholo-${TENANT_NAME} -- bash -c "source /vault/secrets/config && python3 /etc/redis-cleanup/redis-cleanup.py"
}

check_mongo_env() {
    if [ -z "${MONGO_DUMP_FILENAME}" ]
    then
       echo "You need to pass MONGO_DUMP_FILENAME explicitly!"
       exit 1
    fi
}

check_plugins_env() {
    if [ -z "${PLUGINS_DUMP_FILENAME}" ]
    then
       echo "You need to pass PLUGINS_DUMP_FILENAME explicitly!"
       exit 1
    fi
}

if [[ "$MODE" == "restore-all" ]]
then

    check_mongo_env
    check_plugins_env
    scale_down
    create_migration_helper_pod
    redis_cleanup
    kubectl exec --stdin --tty -n kaholo-${TENANT_NAME} kaholo-migration-helper -- \
      bash -c "source /vault/secrets/config && mongorestore --uri=\${DB_URI%\?*} --drop --gzip --archive=/mongo-dump/${MONGO_DUMP_FILENAME}"
    kubectl exec --stdin --tty -n kaholo-${TENANT_NAME} kaholo-migration-helper -- \
      bash -c "rm -rf /bigbird/server/libs/plugins/* && tar -xzf /plugins-dump/plugins/${PLUGINS_DUMP_FILENAME} -C /bigbird/server/libs/plugins"
    kubectl exec --stdin --tty -n kaholo-${TENANT_NAME} kaholo-migration-helper -- \
      bash -c "rm -rf /bigbird/static_cdn/uploads/* && tar -xzf /plugins-dump/uploads/${PLUGINS_DUMP_FILENAME} -C /bigbird/static_cdn/uploads"
    scale_up

elif [[ "$MODE" == "restore-mongo" ]]
then

    check_mongo_env
    scale_down
    create_migration_helper_pod
    redis_cleanup
    kubectl exec --stdin --tty -n kaholo-${TENANT_NAME} kaholo-migration-helper -- \
      bash -c "source /vault/secrets/config && mongorestore --uri=\${DB_URI%\?*} --drop --gzip --archive=/mongo-dump/${MONGO_DUMP_FILENAME}"
    scale_up

elif [[ "$MODE" == "restore-plugins" ]]
then

    check_plugins_env
    scale_down
    create_migration_helper_pod
    kubectl exec --stdin --tty -n kaholo-${TENANT_NAME} kaholo-migration-helper -- \
      bash -c "rm -rf /bigbird/server/libs/plugins/* && tar -xzf /plugins-dump/plugins/${PLUGINS_DUMP_FILENAME} -C /bigbird/server/libs/plugins"
    kubectl exec --stdin --tty -n kaholo-${TENANT_NAME} kaholo-migration-helper -- \
      bash -c "rm -rf /bigbird/static_cdn/uploads/* && tar -xzf /plugins-dump/uploads/${PLUGINS_DUMP_FILENAME} -C /bigbird/static_cdn/uploads"
    scale_up

else

    create_migration_helper_pod
    printf "\n-\nMongo dumps available:\n-\n"
    kubectl exec --stdin --tty -n kaholo-${TENANT_NAME} kaholo-migration-helper -- \
      bash -c "cd /mongo-dump && ls -t"

    printf "\n-\nPlugins dumps available:\n-\n"
    kubectl exec --stdin --tty -n kaholo-${TENANT_NAME} kaholo-migration-helper -- \
      bash -c "cd /plugins-dump/plugins && ls -t"

fi

kubectl delete pod kaholo-migration-helper -n kaholo-${TENANT_NAME}
