#!/bin/bash
set -e  # Exit immediately if a command exits with a non-zero status
set -o pipefail # Causes a pipeline to return the exit status of the last command in the pipe that returned a non-zero return value

ENV=$1
NAMESPACE_NAME=$2
SOURCE_NAMESPACE_NAME=$3
SERVICE_ACCOUNT_KEY_PATH=$4
DB_NAME=$5
SOURCE_DB_NAME=$6
REDIS_URI=$7
VAULT=$8
STORAGE_DUMP_EXISTS=false

if [ -z "$SOURCE_NAMESPACE_NAME" ]; then
  SOURCE_NAMESPACE_NAME=$NAMESPACE_NAME
fi

if [ -z "$DB_NAME" ]; then
  DB_NAME="kaholo"
fi

if ! gcloud storage ls gs://${ENV}-kaholo-cloud-tenants-backups/${SOURCE_NAMESPACE_NAME}/mongo-dump > /dev/null 2>&1
then
    NAMESPACE_NAME=kaholo-$NAMESPACE_NAME
fi

if gcloud storage ls gs://${ENV}-kaholo-cloud-tenants-backups/${SOURCE_NAMESPACE_NAME}/storage-dump > /dev/null 2>&1
then
    STORAGE_DUMP_EXISTS=true
    STORAGE_DUMP_GCS_PATH=$(gcloud storage ls gs://${ENV}-kaholo-cloud-tenants-backups/${SOURCE_NAMESPACE_NAME}/storage-dump | sort -k 2 | tail -1)
    STORAGE_DUMP_DATE=$(echo $STORAGE_DUMP_GCS_PATH | sed -E 's/.*\///' | sed -E 's/T.*//')
fi

MONGO_DUMP_GCS_PATH=$(gcloud storage ls gs://${ENV}-kaholo-cloud-tenants-backups/${SOURCE_NAMESPACE_NAME}/mongo-dump | sort -k 2 | tail -1)
PLUGINS_DUMP_GCS_PATH=$(gcloud storage ls gs://${ENV}-kaholo-cloud-tenants-backups/${SOURCE_NAMESPACE_NAME}/plugins-dump/plugins | sort -k 2 | tail -1)
UPLOADS_DUMP_GCS_PATH=$(gcloud storage ls gs://${ENV}-kaholo-cloud-tenants-backups/${SOURCE_NAMESPACE_NAME}/plugins-dump/uploads | sort -k 2 | tail -1)

MONGO_DUMP_DATE=$(echo $MONGO_DUMP_GCS_PATH | sed -E 's/.*\///' | sed -E 's/T.*//')
PLUGINS_DUMP_DATE=$(echo $PLUGINS_DUMP_GCS_PATH | sed -E 's/.*\///' | sed -E 's/T.*//')
UPLOADS_DUMP_DATE=$(echo $UPLOADS_DUMP_GCS_PATH | sed -E 's/.*\///' | sed -E 's/T.*//')

if $STORAGE_DUMP_EXISTS
then
    if [[ $MONGO_DUMP_DATE != $STORAGE_DUMP_DATE ]] || [[ $STORAGE_DUMP_DATE != $PLUGINS_DUMP_DATE ]] || [[ $PLUGINS_DUMP_DATE != $UPLOADS_DUMP_DATE ]]
    then
        echo "Creation dates of dump files don't match!"
        echo "- MONGO_DUMP_DATE:   $MONGO_DUMP_DATE"
        echo "- STORAGE_DUMP_DATE: $STORAGE_DUMP_DATE"
        echo "- PLUGINS_DUMP_DATE: $PLUGINS_DUMP_DATE"
        echo "- UPLOADS_DUMP_DATE: $UPLOADS_DUMP_DATE"
        exit 1
    fi
else
    if [[ $MONGO_DUMP_DATE != $PLUGINS_DUMP_DATE ]] || [[ $PLUGINS_DUMP_DATE != $UPLOADS_DUMP_DATE ]]
    then
        echo "Creation dates of dump files don't match!"
        echo "- MONGO_DUMP_DATE:   $MONGO_DUMP_DATE"
        echo "- PLUGINS_DUMP_DATE: $PLUGINS_DUMP_DATE"
        echo "- UPLOADS_DUMP_DATE: $UPLOADS_DUMP_DATE"
        exit 1
    fi
fi

if $STORAGE_DUMP_EXISTS
then
    ./TENANT_RESTORE.sh -n $NAMESPACE_NAME -m $MONGO_DUMP_GCS_PATH -p $PLUGINS_DUMP_GCS_PATH -u $UPLOADS_DUMP_GCS_PATH -s $STORAGE_DUMP_GCS_PATH -f $SERVICE_ACCOUNT_KEY_PATH -r $REDIS_URI -d $DB_NAME -e $SOURCE_DB_NAME $VAULT
else
    ./TENANT_RESTORE.sh -n $NAMESPACE_NAME -m $MONGO_DUMP_GCS_PATH -p $PLUGINS_DUMP_GCS_PATH -u $UPLOADS_DUMP_GCS_PATH -f $SERVICE_ACCOUNT_KEY_PATH -r $REDIS_URI -d $DB_NAME -e $SOURCE_DB_NAME $VAULT
fi

printf "\n\nInstance synced from $UPLOADS_DUMP_DATE dumps"
