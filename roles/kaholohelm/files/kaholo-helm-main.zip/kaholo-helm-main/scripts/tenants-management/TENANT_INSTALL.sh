#!/bin/bash -
set -e  # Exit immediately if a command exits with a non-zero status
set -o pipefail # Causes a pipeline to return the exit status of the last command in the pipe that returned a non-zero return value
HOME_DIR=$(pwd)

# Example executions:
# ./TENANT_INSTALL.sh \
#   -t 'cf21fcea6d998481613feace0af5da0abf8604e1' \
#   -n 'departament1' \
#   -d 'mycompany.net' \
#   -s 'kaholo-departament1' \
#   -o 'standard' \
#   -f -b


PROGNAME=$0

usage() {
  cat << EOF >&2
Usage: $PROGNAME

 -t    <KAH_TAG>:         Image Tag of Kaholo containers (required)
 -n    <TENANT_NAME>:     Name of Kaholo instance (required)
 -d    <DOMAIN>:          Domain name used in Ingress resources (required)
 -s    <SUBDOMAIN>:       Subdomain name used in Ingress resources (required)
 -o    <RWO_SC>:          ReadWriteOnce StorageClass name (required)
 -x    <RWM_SC>:          ReadWriteMany StorageClass name (required if DEPLOY_NFS not used, if DEPLOY_NFS is true will be replaced by 'kaholo-${TENANT_NAME}-nfs')
 -k    <SERVER_KEY>:      Server Key used by Kaholo (secret, can be ommited - then will be generated randomly)
 -r    <REGISTRY>:        Container Registry prefix used for pulling the images (default='matankaholo/')
 -m    <MONGO_EXPOSED>:   Set to true/false - decide if MongoDB will be exposed using LoadBalancer services (default=false)
 -b    <BACKUPS>:         Set to true/false - decide if backup creation jobs should be created (default=false)
 -p    <METRICS>:         Set to true/false - decide if Prometheus metrics exporters should be enabled (default=false)
 -a    <AGENT_NODES>      Set to true/false - decide if dedicated K8S nodes with taint/label 'agents' should be used for Kaholo Agents deployments (default=false)
 -c    <CL_DOCKER_NODES>: Set to true/false - decide if dedicated K8S nodes with taint/label 'cl-docker-daemon' should be used for Docker Daemon deployments (default=false)
 -q    <RABBITMQ_TLS>:    Set to true/false - decide if RabbitMQ should be deployed with TLS mode (default=false)
 -g    <CREATE_REGCRED>:  Set to true/false - decide if regcred Secret should be copied from 'shd' namespacae (default=false)
 -w    <CREATE_CERT>:     Set to true/false - decide if wildcard-certificate Secret should be copied from 'shd' namespacae (default=false)
 -f    <DEPLOY_NFS>:      Set to true/false - decide if Custom NFS server should be deployed and used for ReadWriteMany volumes (default=true)

EOF
  exit 1
}

# verbose_level=0
AGENT_KEY=$(tr -dc A-Za-z0-9 </dev/urandom | head -c 32 ; echo '')
SERVER_KEY=$(tr -dc A-Za-z0-9 </dev/urandom | head -c 32 ; echo '')
REGISTRY="matankaholo/"
MONGO_EXPOSED="false"
BACKUPS="false"
METRICS="false"
AGENT_NODES="false"
CL_DOCKER_NODES="false"
RABBITMQ_TLS="false"
CREATE_REGCRED="false"
CREATE_CERT="false"
DEPLOY_NFS="false"
while getopts t:n:d:s:o:x:k:r:mbpacqgwf i; do
  case $i in
    (t) KAH_TAG=$OPTARG;;
    (n) TENANT_NAME=$OPTARG;;
    (d) DOMAIN=$OPTARG;;
    (s) SUBDOMAIN=$OPTARG;;
    (o) RWO_SC=$OPTARG;;
    (x) RWM_SC=$OPTARG;;
    (k) SERVER_KEY=$OPTARG;;
    (r) REGISTRY=$OPTARG;;
    (m) MONGO_EXPOSED=true;;
    (b) BACKUPS=true;;
    (p) METRICS=true;;
    (a) AGENT_NODES=true;;
    (c) CL_DOCKER_NODES=true;;
    (q) RABBITMQ_TLS=true;;
    (g) CREATE_REGCRED=true;;
    (w) CREATE_CERT=true;;
    (f) DEPLOY_NFS=true;;

    (*) usage
  esac
done
shift "$((OPTIND - 1))"

echo Remaining arguments: "$@"


BASE_PATH=$(pwd)/../../

LICENSE_PUBLIC_KEY=$(cat ${BASE_PATH}/kaholo-license.pub)
GITHUB_OAUTH_CLIENT_ID="TODO"
GITHUB_OAUTH_CLIENT_SECRET="TODO"

if [ -z "${KAH_TAG}" ]
then
  echo "You need to pass image tag for Kaholo Platform!"
  exit 1
fi

if [[ "$MONGO_EXPOSED" != "true" ]]
then
  MONGO_EXPOSED="false"
fi

if [[ "$METRICS" != "true" ]]
then
  METRICS="false"
fi

if [[ "$AGENT_NODES" != "true" ]]
then
  AGENT_NODES="false"
fi

if [[ "$CL_DOCKER_NODES" != "true" ]]
then
  CL_DOCKER_NODES="false"
fi

if [[ "$RABBITMQ_TLS" != "true" ]]
then
  RABBITMQ_TLS="false"
fi

if [[ "$DEPLOY_NFS" != "true" ]]
then
  DEPLOY_NFS="false"
else
  RWM_SC="kaholo-${TENANT_NAME}-nfs"
fi
# HOSTNAME=`hostname` ssh-keygen -t rsa -C "code-layer-service" -f "$BASE_PATH/cl_ssh_key" -P "" && cat ${BASE_PATH}/cl_ssh_key.pub
# CODE_LAYER_SSH_KEY=$(cat "$BASE_PATH/cl_ssh_key")
# CODE_LAYER_SSH_KEY_PUB=$(cat "$BASE_PATH/cl_ssh_key.pub")
# rm "$BASE_PATH/cl_ssh_key.pub" "$BASE_PATH/cl_ssh_key"


### Kubernetes namespace creation

kubectl create namespace kaholo-${TENANT_NAME} --dry-run=client -o yaml | kubectl apply -f -


### Secrets preparation

MQ_HOST="rabbitmq:5672"
MQ_PASSWORD_ERLANG_COOKIE=$(tr -dc A-Za-z0-9 </dev/urandom | head -c 30 ; echo '')
MQ_PASSWORD_ADMIN=$(tr -dc A-Za-z0-9 </dev/urandom | head -c 30 ; echo '')
MQ_PASSWORD_BIGBIRD=$(tr -dc A-Za-z0-9 </dev/urandom | head -c 30 ; echo '')
MQ_PASSWORD_TWIDDLEBUG=$(tr -dc A-Za-z0-9 </dev/urandom | head -c 30 ; echo '')
MQ_PASSWORD_CM=$(tr -dc A-Za-z0-9 </dev/urandom | head -c 30 ; echo '')
AMQP_URI_BIGBIRD_RESULTS="amqp://platform:${MQ_PASSWORD_BIGBIRD}@${MQ_HOST}/results"
AMQP_URI_BIGBIRD_ACTIONS="amqp://platform:${MQ_PASSWORD_BIGBIRD}@${MQ_HOST}/actions"
AMQP_URI_BIGBIRD_EVENTS="amqp://platform:${MQ_PASSWORD_BIGBIRD}@${MQ_HOST}/events"

AMQP_URI_TWIDDLEBUG_RESULTS="amqp://agent:${MQ_PASSWORD_TWIDDLEBUG}@${MQ_HOST}/results"
AMQP_URI_TWIDDLEBUG_ACTIONS="amqp://agent:${MQ_PASSWORD_TWIDDLEBUG}@${MQ_HOST}/actions"

AMQP_URI_CM_RESULTS="amqp://service:${MQ_PASSWORD_CM}@${MQ_HOST}/results"
AMQP_URI_CM_ACTIONS="amqp://service:${MQ_PASSWORD_CM}@${MQ_HOST}/actions"
AMQP_URI_CM_EVENTS="amqp://service:${MQ_PASSWORD_CM}@${MQ_HOST}/events"


MONGODB_KAHOLO_PASSWORD=$(tr -dc A-Za-z0-9 </dev/urandom | head -c 30 ; echo '')
MONGODB_ROOT_PASSWORD=$(tr -dc A-Za-z0-9 </dev/urandom | head -c 30 ; echo '')
MONGO_URI="mongodb://kaholo:${MONGODB_KAHOLO_PASSWORD}@mongodb-0.mongodb-headless:27017,mongodb-1.mongodb-headless:27017/kaholo?ssl=false&replicaSet=rs0&retryWrites=true"


REDIS_HOST="redis-master"
REDIS_USERNAME="default"
REDIS_DEFAULT_PASSWORD=$(tr -dc A-Za-z0-9 </dev/urandom | head -c 30 ; echo '')
REDIS_URI="redis://${REDIS_USERNAME}:${REDIS_DEFAULT_PASSWORD}@${REDIS_HOST}:6379"


kubectl create secret generic rabbitmq-password --from-literal=rabbitmq-password=${MQ_PASSWORD_ADMIN} -n kaholo-${TENANT_NAME}
kubectl create secret generic rabbitmq-erlang-cookie --from-literal=rabbitmq-erlang-cookie=${MQ_PASSWORD_ERLANG_COOKIE} -n kaholo-${TENANT_NAME}
kubectl create secret generic mongodb-secret \
    --from-literal=mongodb-passwords="${MONGODB_KAHOLO_PASSWORD}" \
    --from-literal=mongodb-root-password=${MONGODB_ROOT_PASSWORD} \
    --from-literal=mongodb-metrics-password=${MONGODB_ROOT_PASSWORD} \
    --from-literal=mongodb-replica-set-key=${MONGODB_ROOT_PASSWORD} \
    -n kaholo-${TENANT_NAME}
kubectl create secret generic redis-password --from-literal=redis-password=${REDIS_DEFAULT_PASSWORD} -n kaholo-${TENANT_NAME}

tee ${BASE_PATH}/config > /dev/null <<EOT
export LICENSE_PUBLIC_KEY='${LICENSE_PUBLIC_KEY}'
export DB_URI='${MONGO_URI}'
export SERVER_KEY='${SERVER_KEY}'
export REDIS_URL='${REDIS_URI}'
export AMQP_URI_RESULTS='${AMQP_URI_BIGBIRD_RESULTS}'
export AMQP_URI_ACTIONS='${AMQP_URI_BIGBIRD_ACTIONS}'
export AMQP_URI_EVENTS='${AMQP_URI_BIGBIRD_EVENTS}'
export GITHUB_OAUTH_CLIENT_ID='TODO'
export GITHUB_OAUTH_CLIENT_SECRET='TODO'
EOT
kubectl create secret generic platform-env-secret --from-file ${BASE_PATH}/config -n kaholo-${TENANT_NAME}
rm ${BASE_PATH}/config

tee ${BASE_PATH}/config > /dev/null <<EOT
export DB_URI='${MONGO_URI}'
export REDIS_URL='${REDIS_URI}'
export SERVER_KEY='${SERVER_KEY}'
export AMQP_URI_RESULTS='${AMQP_URI_CM_RESULTS}'
export AMQP_URI_ACTIONS='${AMQP_URI_CM_ACTIONS}'
export AMQP_URI_EVENTS='${AMQP_URI_CM_EVENTS}'
EOT
kubectl create secret generic service-env-secret --from-file ${BASE_PATH}/config -n kaholo-${TENANT_NAME}
rm ${BASE_PATH}/config

tee ${BASE_PATH}/config > /dev/null <<EOT
export AMQP_URI_RESULTS='${AMQP_URI_TWIDDLEBUG_RESULTS}'
export AMQP_URI_ACTIONS='${AMQP_URI_TWIDDLEBUG_ACTIONS}'
EOT
kubectl create secret generic agent-env-secret --from-file ${BASE_PATH}/config -n kaholo-${TENANT_NAME}
rm ${BASE_PATH}/config

# tee ${BASE_PATH}/code-layer-ssh-key.pem > /dev/null <<EOT
# ${CODE_LAYER_SSH_KEY}
# EOT
# kubectl create secret generic code-layer-ssh-key-secret --from-file ${BASE_PATH}/code-layer-ssh-key.pem -n kaholo-${TENANT_NAME}
# rm ${BASE_PATH}/code-layer-ssh-key.pem

tee ${BASE_PATH}/load_definition.json > /dev/null <<EOT
{"bindings":[],"exchanges":[],"global_parameters":[],"parameters":[],"permissions":[{"configure":".*","read":".*","user":"admin","vhost":"results","write":".*"},{"configure":".*","read":".*","user":"admin","vhost":"actions","write":".*"},{"configure":".*","read":".*","user":"admin","vhost":"events","write":".*"},{"configure":".*","read":"","user":"platform","vhost":"actions","write":".*"},{"configure":".*","read":".*","user":"platform","vhost":"results","write":""},{"configure":".*","read":".*","user":"platform","vhost":"events","write":".*"},{"configure":".*","read":".*","user":"agent","vhost":"actions","write":""},{"configure":".*","read":"","user":"agent","vhost":"results","write":".*"},{"configure":".*","read":"","user":"service","vhost":"actions","write":".*"},{"configure":".*","read":".*","user":"service","vhost":"results","write":""},{"configure":".*","read":".*","user":"service","vhost":"events","write":".*"}],"users":[{"name":"admin","password":"${MQ_PASSWORD_ADMIN}","tags":"administrator"},{"name":"platform","password":"${MQ_PASSWORD_BIGBIRD}","tags":""},{"name":"agent","password":"${MQ_PASSWORD_TWIDDLEBUG}","tags":""},{"name":"service","password":"${MQ_PASSWORD_CM}","tags":""}],"vhosts":[{"limits":[],"metadata":{"description":"","tags":[]},"name":"results"},{"limits":[],"metadata":{"description":"","tags":[]},"name":"actions"},{"limits":[],"metadata":{"description":"","tags":[]},"name":"events"}]}
EOT
kubectl create secret generic rabbitmq-load-definition --from-file ${BASE_PATH}/load_definition.json -n kaholo-${TENANT_NAME}
rm ${BASE_PATH}/load_definition.json

if [[ "$CREATE_CERT" == "true" ]]
then
  kubectl get secret wildcard-certificate --namespace=shd -o yaml | sed "s/namespace: .*/namespace: kaholo-${TENANT_NAME}/" | kubectl apply -f -
fi

if [[ "$CREATE_REGCRED" == "true" ]]
then
  kubectl get secret regcred --namespace=shd -o yaml | sed "s/namespace: .*/namespace: kaholo-${TENANT_NAME}/" | kubectl apply -f -
fi


## Helm actions

VALUES_FILE_NAME="values-${TENANT_NAME}.yaml"
VALUES_FILE_PATH="${BASE_PATH}/${VALUES_FILE_NAME}"

tee ${VALUES_FILE_PATH} > /dev/null <<EOT

global:
  tenantName: ${TENANT_NAME}
  tenantSubdomain: ${SUBDOMAIN}
  domainName: ${DOMAIN}
  createMigrationJob: true
  codeLayerDockerDaemonK8S: true
  showGithubSsoBtn: true
  imageTag: ${KAH_TAG}
  forceGlobalImageTag: false

quota:
  enabled: true

networkPolicy:
  blockCommandInjectionEgressTraffic: true

backups:
  enabled: ${BACKUPS}
  mongo:
    schedule: "0 3 * * *"
    waitExecutionsFinishTimeoutSeconds: 3600
    cleanup:
      schedule: "0 1 * * *"
      retention:
        days: "7"
    storage:
      accessModes:
      - ReadWriteMany
      storageClassName: ${RWM_SC}
  plugins:
    schedule: "0 3 * * *"
    cleanup:
      schedule: "0 1 * * *"
      retention:
        days: "7"
    storage:
      accessModes:
      - ReadWriteMany
      storageClassName: ${RWM_SC}

experimental:
  dockerCheckpointEnabled: false

integrations:
  gtmContainerID:
  sendGrigApiKey:
  rudderstackWriteKey:
  rudderStackUrl:
  configurationsVideoId: KZt9OyQecDo
  pipelinesVideoId: UK6fHGs0Jr0
  firebaseApiKey: AIzaSyA4BiUvd9tyw2iuK6KMVSiIm9xlt8q4a5U
  firebaseAuthDomain: kaholo-saas-repos.firebaseapp.com
  firebaseProjectId: kaholo-saas-repos
  firebaseStorageBucket: kaholo-saas-repos.appspot.com
  firebaseMessageSenderId: "533560841432"
  firebaseAppId: "1:533560841432:web:687a57c5d240ca3d2133ad"

images:
  repoNamePrefix: ${REGISTRY}
  imagePullSecrets:
  - regcred

actionExecutionService:
  imageName: action-execution-service
  imageTag:

codeLayerService:
  imageName: code-layer-service
  imageTag:

codeLayerImage:
  imageName: code-layer-image
  imageTag:

clDockerDaemon:
  dedicatedNodeGroups: ${CL_DOCKER_NODES}
  docker:
    storage:
      enabled: false
      storageClassName: ${RWO_SC}
      accessModes:
      - ReadWriteOnce

errorService:
  imageName: error-service
  imageTag:

flowControlService:
  imageName: flow-control-service
  imageTag:

websocketService:
  imageName: websocket-service
  imageTag:
  ingress:
    enabled: true
    className: nginx
    serviceName: websocket-service
    servicePort: 80
    tls:
      enabled: true
      host: "*.${DOMAIN}"
      secretName:

mongoService:
  imageName: mongo-service
  imageTag:

pipelineExecutionService:
  imageName: pipeline-execution-service
  imageTag:

queuesService:
  imageName: queues-service
  imageTag:

schedulerService:
  imageName: scheduler-service
  imageTag:

stateService:
  imageName: state-service
  imageTag:

storageService:
  platformSidecar: false
  imageName: storage-service
  imageTag:


platform:
  imageName: platform
  imageTag:
  plugins:
    storage:
      storageClassName: ${RWM_SC}
      accessModes:
      - ReadWriteMany
  pluginscdn:
    storage:
      storageClassName: ${RWM_SC}
      accessModes:
      - ReadWriteMany
  storage:
    dirPath:
    storage:
      storageClassName: ${RWM_SC}
      accessModes:
      - ReadWriteMany
  ingress:
    enabled: true
    className: nginx
    serviceName: platform
    servicePort: 80
    tls:
      enabled: true
      host: "*.${DOMAIN}"
      secretName:
  migrations:
    storage:
      storageClassName: ${RWM_SC}
      accessModes:
      - ReadWriteMany

agent:
  imageName: agent
  imageTag:
  agentKey: ${AGENT_KEY}
  dedicatedNodeGroups: ${AGENT_NODES}
  plugins:
    storage:
      storageClassName: ${RWO_SC}
      accessModes:
      - ReadWriteOnce
  docker:
    storage:
      storageClassName: ${RWO_SC}
      accessModes:
      - ReadWriteOnce

mongodb:
  enabled: true
  fullnameOverride: mongodb
  auth:
    enabled: true
    existingSecret: mongodb-secret
    databases:
    - kaholo
    usernames: 
    - kaholo
  architecture: replicaset
  persistence:
      enabled: true
      storageClass: ${RWO_SC}
      accessModes:
        - ReadWriteOnce
  livenessProbe:
    enabled: false
  readinessProbe:
    enabled: false
  customLivenessProbe:
    tcpSocket:
      port: mongodb
    initialDelaySeconds: 5
    periodSeconds: 20
    timeoutSeconds: 10
    successThreshold: 1
    failureThreshold: 30
  customReadinessProbe:
    tcpSocket:
      port: mongodb
    initialDelaySeconds: 5
    periodSeconds: 10
    timeoutSeconds: 5
    failureThreshold: 6
    successThreshold: 1
  externalAccess:
    enabled: ${MONGO_EXPOSED}
    service:
      type: LoadBalancer
      port: 27017
    autoDiscovery:
      enabled: ${MONGO_EXPOSED}
  serviceAccount:
    create: ${MONGO_EXPOSED}
  rbac:
    create: ${MONGO_EXPOSED}
  metrics:
    enabled: ${METRICS}
    serviceMonitor:
      enabled: true
      additionalLabels:
        release: monitoring

rabbitmq:
  enabled: true
  replicaCount: 1
  service:
    type: ClusterIP
  fullnameOverride: rabbitmq
  loadDefinition:
    enabled: true
    existingSecret: rabbitmq-load-definition
  podLabels:
    app: kaholo-rabbitmq
  extraConfiguration: |
    load_definitions = /app/load_definition.json
  extraEnvVars:
  - name: LOG_LEVEL
    value: error
  auth:
    existingErlangSecret: rabbitmq-erlang-cookie
    existingPasswordSecret: rabbitmq-password
    tls:
      enabled: ${RABBITMQ_TLS}
      failIfNoPeerCert: false
      sslOptionsVerify: verify_none
      existingSecret: wildcard-certificate
      existingSecretFullChain: true
  plugins: "rabbitmq_management rabbitmq_peer_discovery_k8s"
  persistence:
    enabled: true
    storageClass: ${RWO_SC}
  ingress:
    enabled: true
    hostname: ${SUBDOMAIN}-rabbitmq-mgmt.${DOMAIN}
    ingressClassName: nginx
    tls:
      enabled: true
    extraTls:
    - hosts:
      - "*.${DOMAIN}"
      secretName: # wildcard-certificate
  metrics:
    enabled: ${METRICS}
    serviceMonitor:
      enabled: true
      labels:
        release: monitoring

redis:
  fullnameOverride: redis
  enabled: true
  global:
    storageClass: ${RWO_SC}
  auth:
    enabled: true
    existingSecret: redis-password
    existingSecretPasswordKey: redis-password
  master:
    persistence:
      enabled: true
    extraFlags:
    - "--maxmemory 512mb"
    livenessProbe:
      enabled: false
    readinessProbe:
      enabled: false
    customLivenessProbe:
      tcpSocket:
        port: client # named port
      initialDelaySeconds: 30
      timeoutSeconds: 5
      periodSeconds: 5
      failureThreshold: 5
      successThreshold: 1
    customReadinessProbe:
      exec:
        command:
        - redis-cli
        - ping
      initialDelaySeconds: 20
      timeoutSeconds: 5
      periodSeconds: 3
  replica:
    persistence:
      enabled: true
    replicaCount: 1
    extraFlags:
    - "--maxmemory 512mb"
    livenessProbe:
      enabled: false
    readinessProbe:
      enabled: false
    customLivenessProbe:
      tcpSocket:
        port: client # named port
      initialDelaySeconds: 30
      timeoutSeconds: 5
      periodSeconds: 5
      failureThreshold: 5
      successThreshold: 1
    customReadinessProbe:
      exec:
        command:
        - redis-cli
        - ping
      initialDelaySeconds: 20
      timeoutSeconds: 5
      periodSeconds: 3
  metrics:
    enabled: ${METRICS}
    serviceMonitor:
      enabled: true
      additionalLabels:
        release: monitoring

nfs-server-provisioner:
  enabled: ${DEPLOY_NFS}
  persistence:
    enabled: true
    storageClass: ${RWO_SC}
  storageClass:
    name: kaholo-${TENANT_NAME}-nfs

EOT

echo "
Templated values.yaml content for this installation:
$(cat ${VALUES_FILE_PATH})

---
"

echo "
Use below command to do future updates by changing config in ${VALUES_FILE_NAME} file:
helm upgrade kaholo-${TENANT_NAME} . -n kaholo-${TENANT_NAME} -f ${VALUES_FILE_NAME} --description \"description\"

To see only the diff of changes that will be made, you can use Helm Diff Plugin (https://github.com/databus23/helm-diff):
helm diff upgrade kaholo-${TENANT_NAME} . -n kaholo-${TENANT_NAME} -f ${VALUES_FILE_NAME}

Remember to save your file ${VALUES_FILE_NAME}, it's a configuration of your Kaholo instance :)
"

# helm diff upgrade kaholo-${TENANT_NAME} ${BASE_PATH} -n kaholo-${TENANT_NAME} -f ${VALUES_FILE_PATH}
helm install kaholo-${TENANT_NAME} ${BASE_PATH} -n kaholo-${TENANT_NAME} --create-namespace -f ${VALUES_FILE_PATH}

# rm ${VALUES_FILE_PATH}
