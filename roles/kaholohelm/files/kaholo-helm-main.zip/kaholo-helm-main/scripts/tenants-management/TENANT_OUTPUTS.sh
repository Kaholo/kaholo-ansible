#!/bin/bash
set -e  # Exit immediately if a command exits with a non-zero status
set -o pipefail # Causes a pipeline to return the exit status of the last command in the pipe that returned a non-zero return value
HOME_DIR=$(pwd)

TENANT_NAME=$1
DOMAIN_NAME=$2
TENANT_SUBDOMAIN=$3

MONGO_HOST1=""; while [ -z $MONGO_HOST1 ]; do echo "Waiting for end point..."; MONGO_HOST1=$(kubectl get svc mongodb-0-external -n kaholo-${TENANT_NAME} --template="{{range .status.loadBalancer.ingress}}{{.ip}}{{end}}"); [ -z "$MONGO_HOST1" ] && sleep 10; done; echo "End point ready-" && echo $MONGO_HOST1;
MONGO_HOST2=""; while [ -z $MONGO_HOST2 ]; do echo "Waiting for end point..."; MONGO_HOST2=$(kubectl get svc mongodb-1-external -n kaholo-${TENANT_NAME} --template="{{range .status.loadBalancer.ingress}}{{.ip}}{{end}}"); [ -z "$MONGO_HOST2" ] && sleep 10; done; echo "End point ready-" && echo $MONGO_HOST2;
MONGO_PASSWORD=$(kubectl get secret mongodb-secret -n kaholo-${TENANT_NAME} -o jsonpath="{.data.mongodb-passwords}" | base64 -d)
MONGO_URI="mongodb://kaholo:${MONGO_PASSWORD}@${MONGO_HOST1}:27017,${MONGO_HOST2}:27017/kaholo?replicaSet=rs0"
RABBITMQ_PASSWORD=$(kubectl get secret rabbitmq-password -n kaholo-${TENANT_NAME} -o jsonpath="{.data.rabbitmq-password}" | base64 -d)

echo "
Your tenant will be available here: https://${TENANT_SUBDOMAIN}.${DOMAIN_NAME}

You can use below data to access necessary services for debugging purposes

Mongo URI:         $MONGO_URI
MQ URL:            https://${TENANT_SUBDOMAIN}-rabbitmq-mgmt.kaholo.net
MQ login data:     admin / ${RABBITMQ_PASSWORD}

If you want to access Kuberentes resources or Redis please contact with Devops Engineer

"
